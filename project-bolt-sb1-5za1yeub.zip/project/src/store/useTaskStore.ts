import { create } from 'zustand';
import type { Task } from '../lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '../lib/storage';
import { uid } from '../lib/id';
import { today } from '../lib/date';

interface TaskState {
  tasks: Task[];
  addTask: (t: Omit<Task, 'id' | 'completed' | 'completedAt' | 'createdAt'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTask: (id: string) => void;
  generateRecurring: () => void;
}

export const useTaskStore = create<TaskState>((set, get) => ({
  tasks: loadFromStorage<Task[]>(STORAGE_KEYS.tasks, []),

  addTask: (t) => {
    const task: Task = {
      ...t, id: uid(), completed: false, completedAt: null,
      createdAt: new Date().toISOString(),
    };
    const tasks = [...get().tasks, task];
    saveToStorage(STORAGE_KEYS.tasks, tasks);
    set({ tasks });
  },

  updateTask: (id, updates) => {
    const tasks = get().tasks.map((t) => (t.id === id ? { ...t, ...updates } : t));
    saveToStorage(STORAGE_KEYS.tasks, tasks);
    set({ tasks });
  },

  deleteTask: (id) => {
    const tasks = get().tasks.filter((t) => t.id !== id);
    saveToStorage(STORAGE_KEYS.tasks, tasks);
    set({ tasks });
  },

  toggleTask: (id) => {
    const tasks = get().tasks.map((t) =>
      t.id === id ? { ...t, completed: !t.completed, completedAt: !t.completed ? new Date().toISOString() : null } : t
    );
    saveToStorage(STORAGE_KEYS.tasks, tasks);
    set({ tasks });
  },

  generateRecurring: () => {
    const tasks = get().tasks;
    const todayStr = today();
    const existingKeys = new Set(tasks.filter((t) => t.dueDate).map((t) => `${t.title}-${t.dueDate}`));
    const newTasks: Task[] = [];

    for (const t of tasks) {
      if (t.recurring === 'none') continue;
      if (!t.completed && t.dueDate === todayStr) continue;

      const shouldGenerate = (() => {
        if (t.recurring === 'daily') return true;
        if (t.recurring === 'weekdays') { const d = new Date().getDay(); return d >= 1 && d <= 5; }
        if (t.recurring === 'weekly') { const orig = t.dueDate ? new Date(t.dueDate).getDay() : -1; return new Date().getDay() === orig; }
        return false;
      })();

      if (!shouldGenerate) continue;
      const key = `${t.title}-${todayStr}`;
      if (existingKeys.has(key)) continue;

      newTasks.push({
        id: uid(), title: t.title, dueDate: todayStr, dueTime: t.dueTime,
        recurring: t.recurring, completed: false, completedAt: null,
        createdAt: new Date().toISOString(),
      });
    }

    if (newTasks.length > 0) {
      const updated = [...tasks, ...newTasks];
      saveToStorage(STORAGE_KEYS.tasks, updated);
      set({ tasks: updated });
    }
  },
}));
