import { create } from 'zustand';
import type { FoodEntry, WeightEntry } from '../lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '../lib/storage';
import { uid } from '../lib/id';
import { today } from '../lib/date';

interface DietState {
  foodEntries: FoodEntry[];
  weightEntries: WeightEntry[];
  addFoodEntry: (e: Omit<FoodEntry, 'id' | 'timestamp'>) => void;
  deleteFoodEntry: (id: string) => void;
  addWeightEntry: (weight: number, goalWeight: number, targetDate: string) => void;
  todayMacros: () => { protein: number; carbs: number; fats: number; calories: number };
  todayEntries: () => FoodEntry[];
}

export const useDietStore = create<DietState>((set, get) => ({
  foodEntries: loadFromStorage<FoodEntry[]>(STORAGE_KEYS.foodEntries, []),
  weightEntries: loadFromStorage<WeightEntry[]>(STORAGE_KEYS.weightEntries, []),

  addFoodEntry: (e) => {
    const entry: FoodEntry = { ...e, id: uid(), timestamp: new Date().toISOString() };
    const foodEntries = [...get().foodEntries, entry];
    saveToStorage(STORAGE_KEYS.foodEntries, foodEntries);
    set({ foodEntries });
  },

  deleteFoodEntry: (id) => {
    const foodEntries = get().foodEntries.filter((e) => e.id !== id);
    saveToStorage(STORAGE_KEYS.foodEntries, foodEntries);
    set({ foodEntries });
  },

  addWeightEntry: (weight, goalWeight, targetDate) => {
    const entry: WeightEntry = { id: uid(), weight, date: today(), goalWeight, targetDate };
    const weightEntries = [...get().weightEntries, entry];
    saveToStorage(STORAGE_KEYS.weightEntries, weightEntries);
    set({ weightEntries });
  },

  todayMacros: () => {
    const t = today();
    return get().foodEntries
      .filter((e) => e.timestamp.startsWith(t))
      .reduce((acc, e) => ({
        protein: acc.protein + e.protein, carbs: acc.carbs + e.carbs,
        fats: acc.fats + e.fats, calories: acc.calories + e.calories,
      }), { protein: 0, carbs: 0, fats: 0, calories: 0 });
  },

  todayEntries: () => {
    const t = today();
    return get().foodEntries.filter((e) => e.timestamp.startsWith(t));
  },
}));
