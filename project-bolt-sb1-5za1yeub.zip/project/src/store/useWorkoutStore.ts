import { create } from 'zustand';
import type { Workout } from '../lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '../lib/storage';
import { uid } from '../lib/id';
import { today, last7Days } from '../lib/date';

interface WorkoutState {
  workouts: Workout[];
  addWorkout: (w: Omit<Workout, 'id' | 'timestamp'>) => void;
  deleteWorkout: (id: string) => void;
  todayWorkouts: () => Workout[];
  weekCalories: () => number;
  weekWorkouts: () => Workout[];
  weekMinutes: () => number;
}

export const useWorkoutStore = create<WorkoutState>((set, get) => ({
  workouts: loadFromStorage<Workout[]>(STORAGE_KEYS.workouts, []),

  addWorkout: (w) => {
    const workout: Workout = { ...w, id: uid(), timestamp: new Date().toISOString() };
    const workouts = [...get().workouts, workout];
    saveToStorage(STORAGE_KEYS.workouts, workouts);
    set({ workouts });
  },

  deleteWorkout: (id) => {
    const workouts = get().workouts.filter((w) => w.id !== id);
    saveToStorage(STORAGE_KEYS.workouts, workouts);
    set({ workouts });
  },

  todayWorkouts: () => {
    const t = today();
    return get().workouts.filter((w) => w.timestamp.startsWith(t));
  },

  weekWorkouts: () => {
    const days = last7Days();
    return get().workouts.filter((w) => days.some((d) => w.timestamp.startsWith(d)));
  },

  weekCalories: () => get().weekWorkouts().reduce((s, w) => s + w.caloriesBurned, 0),

  weekMinutes: () => get().weekWorkouts().reduce((s, w) => s + w.duration, 0),
}));
