import { create } from 'zustand';
import type { ChatMessage } from '../lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '../lib/storage';
import { uid } from '../lib/id';

interface ChatState {
  messages: ChatMessage[];
  addMessage: (m: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: loadFromStorage<ChatMessage[]>(STORAGE_KEYS.chatMessages, []),

  addMessage: (m) => {
    const msg: ChatMessage = { ...m, id: uid(), timestamp: new Date().toISOString() };
    const messages = [...get().messages, msg];
    saveToStorage(STORAGE_KEYS.chatMessages, messages);
    set({ messages });
  },

  clearMessages: () => {
    saveToStorage(STORAGE_KEYS.chatMessages, []);
    set({ messages: [] });
  },
}));
