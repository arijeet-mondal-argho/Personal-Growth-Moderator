import { create } from 'zustand';
import type { StudySubject, StudySession } from '../lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '../lib/storage';
import { uid } from '../lib/id';
import { today, last7Days } from '../lib/date';

interface StudyState {
  subjects: StudySubject[];
  sessions: StudySession[];
  addSubject: (s: Omit<StudySubject, 'id'>) => void;
  deleteSubject: (id: string) => void;
  addSession: (s: Omit<StudySession, 'id'>) => void;
  deleteSession: (id: string) => void;
  toggleSession: (id: string) => void;
  todaySessions: () => StudySession[];
  todayMinutesBySubject: () => Record<string, number>;
  weekMinutes: () => number;
  streakDays: () => number;
}

export const useStudyStore = create<StudyState>((set, get) => ({
  subjects: loadFromStorage<StudySubject[]>(STORAGE_KEYS.studySubjects, []),
  sessions: loadFromStorage<StudySession[]>(STORAGE_KEYS.studySessions, []),

  addSubject: (s) => {
    const subjects = [...get().subjects, { ...s, id: uid() }];
    saveToStorage(STORAGE_KEYS.studySubjects, subjects);
    set({ subjects });
  },

  deleteSubject: (id) => {
    const subjects = get().subjects.filter((s) => s.id !== id);
    const sessions = get().sessions.filter((s) => s.subjectId !== id);
    saveToStorage(STORAGE_KEYS.studySubjects, subjects);
    saveToStorage(STORAGE_KEYS.studySessions, sessions);
    set({ subjects, sessions });
  },

  addSession: (s) => {
    const sessions = [...get().sessions, { ...s, id: uid() }];
    saveToStorage(STORAGE_KEYS.studySessions, sessions);
    set({ sessions });
  },

  deleteSession: (id) => {
    const sessions = get().sessions.filter((s) => s.id !== id);
    saveToStorage(STORAGE_KEYS.studySessions, sessions);
    set({ sessions });
  },

  toggleSession: (id) => {
    const sessions = get().sessions.map((s) => s.id === id ? { ...s, completed: !s.completed } : s);
    saveToStorage(STORAGE_KEYS.studySessions, sessions);
    set({ sessions });
  },

  todaySessions: () => {
    const t = today();
    return get().sessions.filter((s) => s.date === t);
  },

  todayMinutesBySubject: () => {
    const t = today();
    const map: Record<string, number> = {};
    get().sessions.filter((s) => s.date === t && s.completed).forEach((s) => {
      map[s.subjectId] = (map[s.subjectId] || 0) + s.duration;
    });
    return map;
  },

  weekMinutes: () => {
    const days = last7Days();
    return get().sessions.filter((s) => days.includes(s.date) && s.completed).reduce((sum, s) => sum + s.duration, 0);
  },

  streakDays: () => {
    let streak = 0;
    const d = new Date();
    while (true) {
      const dateStr = d.toISOString().split('T')[0];
      if (!get().sessions.some((s) => s.date === dateStr && s.completed)) break;
      streak++;
      d.setDate(d.getDate() - 1);
    }
    return streak;
  },
}));
