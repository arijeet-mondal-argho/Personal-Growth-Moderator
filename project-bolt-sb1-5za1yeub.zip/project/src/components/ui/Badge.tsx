import type { ReactNode } from 'react';

interface BadgeProps {
  variant?: 'primary' | 'accent' | 'warning' | 'error' | 'success' | 'neutral';
  children: ReactNode;
  className?: string;
}

const variants = {
  primary: 'badge-primary',
  accent: 'badge-accent',
  warning: 'badge-warning',
  error: 'badge-error',
  success: 'badge-success',
  neutral: 'badge bg-slate-500/20 text-slate-400',
};

export default function Badge({ variant = 'primary', children, className = '' }: BadgeProps) {
  return <span className={`${variants[variant]} ${className}`}>{children}</span>;
}
