import { LayoutDashboard, CheckSquare, Utensils, Dumbbell, BookOpen, MessageCircle } from 'lucide-react';
import type { NavTab } from '../../lib/types';

const tabs: { id: NavTab; label: string; Icon: typeof CheckSquare }[] = [
  { id: 'dashboard', label: 'Home', Icon: LayoutDashboard },
  { id: 'tasks', label: 'Tasks', Icon: CheckSquare },
  { id: 'diet', label: 'Diet', Icon: Utensils },
  { id: 'workout', label: 'Workout', Icon: Dumbbell },
  { id: 'study', label: 'Study', Icon: BookOpen },
  { id: 'chat', label: 'Chat', Icon: MessageCircle },
];

export default function BottomNav({ active, onChange }: { active: NavTab; onChange: (tab: NavTab) => void }) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 z-40 safe-bottom">
      <div className="flex items-center justify-around max-w-lg mx-auto h-14">
        {tabs.map(({ id, label, Icon }) => {
          const isActive = active === id;
          return (
            <button key={id} onClick={() => onChange(id)}
              className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-colors ${
                isActive ? 'text-primary-400' : 'text-slate-500 hover:text-slate-300'}`}>
              <Icon size={20} strokeWidth={isActive ? 2.5 : 1.5} />
              <span className={`text-[10px] font-medium ${isActive ? 'text-primary-400' : ''}`}>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
