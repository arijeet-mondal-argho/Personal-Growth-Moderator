export interface Task {
  id: string;
  title: string;
  dueDate: string | null;
  dueTime: string | null;
  recurring: 'none' | 'daily' | 'weekdays' | 'weekly';
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
}

export interface FoodEntry {
  id: string;
  name: string;
  meal: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  protein: number;
  carbs: number;
  fats: number;
  calories: number;
  timestamp: string;
}

export interface WeightEntry {
  id: string;
  weight: number;
  date: string;
  goalWeight: number;
  targetDate: string;
}

export interface Workout {
  id: string;
  name: string;
  type: 'strength' | 'cardio' | 'flexibility' | 'sports';
  duration: number;
  caloriesBurned: number;
  exercises: ExerciseEntry[];
  timestamp: string;
}

export interface ExerciseEntry {
  name: string;
  sets?: number;
  reps?: number;
  weight?: number;
  duration?: number;
  notes?: string;
}

export interface StudySubject {
  id: string;
  name: string;
  color: string;
  dailyGoalMinutes: number;
}

export interface StudySession {
  id: string;
  subjectId: string;
  duration: number;
  completed: boolean;
  date: string;
  notes?: string;
}

export type ChatIntent =
  | 'diet' | 'workout' | 'study' | 'productivity'
  | 'habits' | 'routine' | 'reminders' | 'safety_escalation'
  | 'general_help' | 'greeting';

export type ConfidenceLevel = 'high' | 'medium' | 'low' | 'unsafe';
export type Language = 'en' | 'bn' | 'bnEn';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  confidence?: ConfidenceLevel;
  source?: string;
  intent?: ChatIntent;
  suggestions?: string[];
}

export type NavTab = 'dashboard' | 'tasks' | 'diet' | 'workout' | 'study' | 'chat';

export interface ChatRule {
  id: string;
  triggers: string[];
  intent: ChatIntent;
  responseTemplates: { en: string; bn: string; bnEn: string };
  safetyLevel: 'safe' | 'caution' | 'escalate';
  confidence: ConfidenceLevel;
  source: string;
  lastUpdated: string;
}
