export const MACRO_PRESETS: Record<string, { protein: number; carbs: number; fats: number; calories: number }> = {
  'Chicken Breast (100g)': { protein: 31, carbs: 0, fats: 3.6, calories: 165 },
  'Rice (1 cup cooked)': { protein: 4.3, carbs: 45, fats: 0.4, calories: 206 },
  'Egg (1 large)': { protein: 6.3, carbs: 0.6, fats: 5, calories: 72 },
  'Banana (1 medium)': { protein: 1.3, carbs: 27, fats: 0.4, calories: 105 },
  'Milk (1 cup)': { protein: 8, carbs: 12, fats: 8, calories: 149 },
  'Oats (1 cup dry)': { protein: 10.7, carbs: 54, fats: 5.3, calories: 307 },
  'Bread (2 slices)': { protein: 7, carbs: 24, fats: 2, calories: 140 },
  'Dal/Lentils (1 cup)': { protein: 18, carbs: 40, fats: 0.8, calories: 230 },
  'Roti/Chapati (1 piece)': { protein: 3, carbs: 15, fats: 3.7, calories: 104 },
  'Fish (100g)': { protein: 20, carbs: 0, fats: 5, calories: 125 },
  'Beef (100g)': { protein: 26, carbs: 0, fats: 15, calories: 250 },
  'Almonds (28g)': { protein: 6, carbs: 6, fats: 14, calories: 164 },
  'Curd/Yogurt (1 cup)': { protein: 11, carbs: 16, fats: 4, calories: 148 },
  'Paneer (100g)': { protein: 18, carbs: 1.2, fats: 21, calories: 265 },
  'Vegetable Curry (1 cup)': { protein: 5, carbs: 15, fats: 8, calories: 150 },
};

export const EXERCISE_PRESETS: Record<string, { caloriesPerMinute: number; type: 'strength' | 'cardio' | 'flexibility' }> = {
  'Push-ups': { caloriesPerMinute: 7, type: 'strength' },
  'Pull-ups': { caloriesPerMinute: 8, type: 'strength' },
  'Squats': { caloriesPerMinute: 6, type: 'strength' },
  'Deadlift': { caloriesPerMinute: 6, type: 'strength' },
  'Bench Press': { caloriesPerMinute: 5, type: 'strength' },
  'Running': { caloriesPerMinute: 11, type: 'cardio' },
  'Walking': { caloriesPerMinute: 4, type: 'cardio' },
  'Cycling': { caloriesPerMinute: 8, type: 'cardio' },
  'Jump Rope': { caloriesPerMinute: 12, type: 'cardio' },
  'Swimming': { caloriesPerMinute: 9, type: 'cardio' },
  'Yoga': { caloriesPerMinute: 3, type: 'flexibility' },
  'Stretching': { caloriesPerMinute: 2, type: 'flexibility' },
};

export const SUBJECT_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
  '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1',
];

export const CONFIDENCE_COLORS: Record<string, string> = {
  high: 'bg-success-500/20 text-success-400',
  medium: 'bg-warning-500/20 text-warning-400',
  low: 'bg-slate-500/20 text-slate-400',
  unsafe: 'bg-error-500/20 text-error-400',
};
