export function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // Storage full
  }
}

export const STORAGE_KEYS = {
  tasks: 'growthapp_tasks',
  foodEntries: 'growthapp_food',
  weightEntries: 'growthapp_weight',
  workouts: 'growthapp_workouts',
  studySubjects: 'growthapp_study_subjects',
  studySessions: 'growthapp_study_sessions',
  chatMessages: 'growthapp_chat',
  activeTab: 'growthapp_active_tab',
} as const;
