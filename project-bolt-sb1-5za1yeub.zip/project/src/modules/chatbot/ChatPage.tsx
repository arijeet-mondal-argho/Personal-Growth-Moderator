import { useState, useRef, useEffect } from 'react';
import { Send, MessageCircle, Sparkles, Shield, Trash2 } from 'lucide-react';
import { useChatStore } from '../../store/useChatStore';
import { processMessage } from '../../chatbot/engine';
import { CONFIDENCE_COLORS } from '../../lib/constants';
import type { ChatMessage, ConfidenceLevel } from '../../lib/types';

const QUICK_PROMPTS = [
  'How much protein do I need?',
  'Study tips for exams',
  'Beginner workout plan',
  'How to build habits',
  'Morning routine tips',
];

const CONFIDENCE_LABELS: Record<ConfidenceLevel, string> = {
  high: 'Reliable', medium: 'Likely helpful', low: 'General guidance', unsafe: 'Escalated',
};

export default function ChatPage() {
  const { messages, clearMessages } = useChatStore();
  const [input, setInput] = useState('');
  const [showClear, setShowClear] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = (text?: string) => {
    const msg = text || input.trim();
    if (!msg) return;
    setInput('');
    processMessage(msg);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 pt-5 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center"><MessageCircle size={20} className="text-white" /></div>
          <div><h1 className="text-xl font-bold text-slate-100">Growth Coach</h1><p className="text-xs text-slate-500">Evidence-based guidance</p></div>
        </div>
        {messages.length > 0 && (
          <button onClick={() => setShowClear(true)} className="p-2 rounded-lg hover:bg-slate-800 text-slate-500"><Trash2 size={18} /></button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 px-4 overflow-y-auto scrollbar-hide">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <MessageCircle size={44} className="text-slate-700 mb-3" />
            <p className="text-base font-semibold text-slate-500">Ask me anything</p>
            <p className="text-sm text-slate-600 mt-1">Get advice on diet, workouts, study, habits</p>
          </div>
        ) : (
          <div className="space-y-3 pb-4">
            {messages.map((msg) => <ChatBubble key={msg.id} message={msg} />)}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      {messages.length === 0 && (
        <div className="px-4 pb-2">
          <div className="flex flex-wrap gap-2">
            {QUICK_PROMPTS.map((prompt) => (
              <button key={prompt} onClick={() => handleSend(prompt)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-full text-xs text-slate-300 transition-colors">{prompt}</button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-4 pb-4 pt-2 border-t border-slate-800 bg-slate-950">
        <div className="flex items-center gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Ask about diet, study, workouts..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none" />
          <button onClick={() => handleSend()} disabled={!input.trim()}
            className="w-10 h-10 bg-primary-600 hover:bg-primary-500 disabled:bg-slate-700 disabled:text-slate-500 rounded-xl flex items-center justify-center text-white transition-colors">
            <Send size={18} />
          </button>
        </div>
      </div>

      {/* Clear Modal */}
      {showClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowClear(false)} />
          <div className="relative bg-slate-900 border border-slate-800 rounded-2xl p-5 mx-4 w-full max-w-sm shadow-2xl">
            <h3 className="text-base font-semibold text-slate-100 mb-2">Clear Chat</h3>
            <p className="text-sm text-slate-400 mb-4">This will delete all chat history. This cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setShowClear(false)} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
              <button onClick={() => { clearMessages(); setShowClear(false); }}
                className="flex-1 px-4 py-2.5 bg-error-600 hover:bg-error-500 text-white font-medium rounded-lg text-sm transition-colors">Clear All</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ChatBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[85%] ${isUser ? 'order-2' : 'order-1'}`}>
        {!isUser && (
          <div className="flex items-center gap-1.5 mb-1">
            <Sparkles size={12} className="text-primary-400" />
            <span className="text-xs text-slate-500">Growth Coach</span>
            {message.confidence && (
              <span className={`${CONFIDENCE_COLORS[message.confidence]} rounded-full px-1.5 py-0.5 text-[10px] font-medium`}>
                {CONFIDENCE_LABELS[message.confidence]}
              </span>
            )}
          </div>
        )}
        <div className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
          isUser ? 'bg-primary-600 text-white rounded-br-md' : 'bg-slate-800 text-slate-200 rounded-bl-md'}`}>
          {message.content.split('\n').map((line, i) => (
            <p key={i} className={line.startsWith('_') ? 'text-xs text-slate-500 italic' : ''}>
              {line.startsWith('_') ? line.replace(/_/g, '') : line}
              {i < message.content.split('\n').length - 1 && <br />}
            </p>
          ))}
        </div>
        {!isUser && message.source && (
          <div className="flex items-center gap-2 mt-1 px-1"><Shield size={10} className="text-slate-600" /><span className="text-[10px] text-slate-600">{message.source}</span></div>
        )}
        {!isUser && message.suggestions && message.suggestions.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {message.suggestions.map((s) => (
              <button key={s} onClick={() => processMessage(s)}
                className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-full text-xs text-slate-400 transition-colors">{s}</button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
