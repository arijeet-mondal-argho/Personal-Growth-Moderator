import { useState } from 'react';
import { Plus, BookOpen, Clock, Check, Trash2, Edit3, X, Flame } from 'lucide-react';
import { useStudyStore } from '../../store/useStudyStore';
import ProgressRing from '../../components/ui/ProgressRing';
import Badge from '../../components/ui/Badge';
import { SUBJECT_COLORS } from '../../lib/constants';
import { today } from '../../lib/date';
import type { StudySubject } from '../../lib/types';

export default function StudyPage() {
  const {
    subjects, addSubject, deleteSubject, addSession, deleteSession, toggleSession,
    todaySessions, todayMinutesBySubject, weekMinutes, streakDays,
  } = useStudyStore();

  const [showSubjectForm, setShowSubjectForm] = useState(false);
  const [showSessionForm, setShowSessionForm] = useState(false);
  const [editingSubject, setEditingSubject] = useState<StudySubject | null>(null);
  const [subjectFilter, setSubjectFilter] = useState<string | null>(null);

  const todayList = todaySessions();
  const minutesBySubject = todayMinutesBySubject();
  const weekMins = weekMinutes();
  const streak = streakDays();
  const filteredSessions = subjectFilter ? todayList.filter((s) => s.subjectId === subjectFilter) : todayList;
  const completedToday = todayList.filter((s) => s.completed).length;
  const totalToday = todayList.length;

  return (
    <div className="h-full overflow-y-auto pb-4 scrollbar-hide">
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center"><BookOpen size={20} className="text-white" /></div>
          <div><h1 className="text-xl font-bold text-slate-100">Study</h1><p className="text-xs text-slate-500">{completedToday}/{totalToday} done today</p></div>
        </div>
      </div>

      {/* Summary */}
      <div className="px-4 mt-2 grid grid-cols-3 gap-2">
        <div className="card text-center py-3"><p className="text-lg font-bold text-primary-400">{weekMins}</p><p className="text-xs text-slate-500">min/week</p></div>
        <div className="card text-center py-3"><p className="text-lg font-bold text-accent-400 flex items-center justify-center gap-1"><Flame size={14} />{streak}</p><p className="text-xs text-slate-500">day streak</p></div>
        <div className="card text-center py-3"><p className="text-lg font-bold text-warning-400">{subjects.length}</p><p className="text-xs text-slate-500">subjects</p></div>
      </div>

      {/* Subject Progress */}
      {subjects.length > 0 && (
        <div className="px-4 mt-4">
          <p className="section-title mb-2">Today's Progress</p>
          <div className="grid grid-cols-3 gap-2">
            {subjects.map((sub) => {
              const done = minutesBySubject[sub.id] || 0;
              const progress = sub.dailyGoalMinutes > 0 ? Math.min(100, Math.round((done / sub.dailyGoalMinutes) * 100)) : 0;
              return (
                <div key={sub.id} onClick={() => setSubjectFilter(subjectFilter === sub.id ? null : sub.id)} className="cursor-pointer">
                  <ProgressRing progress={progress} size={68} strokeWidth={5} color={sub.color} label={`${done}/${sub.dailyGoalMinutes}`} sublabel={sub.name.slice(0, 8)} />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Subjects */}
      <div className="px-4 mt-4">
        <div className="flex items-center justify-between mb-2">
          <p className="section-title">Subjects</p>
          <button onClick={() => { setEditingSubject(null); setShowSubjectForm(true); }} className="px-2 py-1 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"><Plus size={14} />Add</button>
        </div>
        {subjects.length === 0 ? (
          <div className="flex flex-col items-center py-12 text-center">
            <BookOpen size={40} className="text-slate-700 mb-3" />
            <p className="text-base font-semibold text-slate-500">No subjects yet</p>
            <p className="text-sm text-slate-600 mt-1">Add subjects to plan study sessions</p>
          </div>
        ) : (
          <div className="space-y-2">
            {subjects.map((sub) => (
              <div key={sub.id} className="card flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: sub.color }} />
                  <div><p className="text-sm font-medium text-slate-200">{sub.name}</p><p className="text-xs text-slate-500">{sub.dailyGoalMinutes} min/day</p></div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => { setEditingSubject(sub); setShowSubjectForm(true); }} className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-500"><Edit3 size={14} /></button>
                  <button onClick={() => deleteSubject(sub.id)} className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-500 hover:text-error-400"><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Today's Sessions */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-2">
          <p className="section-title">
            Today's Sessions
            {subjectFilter && <Badge variant="neutral" className="ml-2">{subjects.find((s) => s.id === subjectFilter)?.name}<X size={10} className="ml-1 cursor-pointer" onClick={() => setSubjectFilter(null)} /></Badge>}
          </p>
          <button onClick={() => setShowSessionForm(true)} className="px-2 py-1 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"><Plus size={14} />Add</button>
        </div>
        {filteredSessions.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-4">No study sessions planned for today</p>
        ) : (
          <div className="space-y-2">
            {filteredSessions.map((session) => {
              const subject = subjects.find((s) => s.id === session.subjectId);
              return (
                <div key={session.id} className="card flex items-center gap-3">
                  <button onClick={() => toggleSession(session.id)}
                    className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-colors ${session.completed ? 'bg-accent-600 border-accent-600' : 'border-slate-600'}`}>
                    {session.completed && <Check size={12} className="text-white" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium ${session.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>{subject?.name || 'Unknown'}</p>
                    <span className="text-xs text-slate-500 flex items-center gap-1"><Clock size={10} />{session.duration} min</span>
                  </div>
                  <button onClick={() => deleteSession(session.id)} className="p-1 text-slate-600 hover:text-error-400"><Trash2 size={14} /></button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAB */}
      <button onClick={() => setShowSessionForm(true)}
        className="fixed bottom-20 right-4 w-14 h-14 bg-purple-600 hover:bg-purple-500 rounded-full shadow-lg shadow-purple-600/30 flex items-center justify-center transition-colors z-30">
        <Plus size={24} className="text-white" />
      </button>

      <SubjectFormModal open={showSubjectForm} subject={editingSubject} onClose={() => { setShowSubjectForm(false); setEditingSubject(null); }}
        onSave={(data) => { if (editingSubject) { /* update not in store yet, skip */ } else addSubject(data); setShowSubjectForm(false); setEditingSubject(null); }} />
      <SessionFormModal open={showSessionForm} subjects={subjects} onClose={() => setShowSessionForm(false)} onSave={addSession} />
    </div>
  );
}

function SubjectFormModal({ open, subject, onClose, onSave }: {
  open: boolean; subject: StudySubject | null; onClose: () => void;
  onSave: (data: Omit<StudySubject, 'id'>) => void;
}) {
  const [name, setName] = useState('');
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState('60');
  const [colorIndex, setColorIndex] = useState(0);

  const reset = () => { setName(''); setDailyGoalMinutes('60'); setColorIndex(0); };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { reset(); onClose(); }} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">{subject ? 'Edit Subject' : 'New Subject'}</h2>
          <button onClick={() => { reset(); onClose(); }} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4">
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Subject name</label><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Mathematics" className="input-field" /></div>
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Daily goal (minutes)</label><input type="number" value={dailyGoalMinutes} onChange={(e) => setDailyGoalMinutes(e.target.value)} className="input-field" /></div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Color</label>
            <div className="flex gap-2 flex-wrap">
              {SUBJECT_COLORS.map((c, i) => (
                <button key={c} onClick={() => setColorIndex(i)}
                  className={`w-8 h-8 rounded-full border-2 transition-transform ${colorIndex === i ? 'border-white scale-110' : 'border-transparent'}`}
                  style={{ backgroundColor: c }} />
              ))}
            </div>
          </div>
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={() => { reset(); onClose(); }} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!name.trim()) return; onSave({ name: name.trim(), dailyGoalMinutes: +dailyGoalMinutes || 60, color: SUBJECT_COLORS[colorIndex] }); reset(); onClose(); }}
            disabled={!name.trim()} className="flex-1 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">
            {subject ? 'Update' : 'Add Subject'}
          </button>
        </div>
      </div>
    </div>
  );
}

function SessionFormModal({ open, subjects, onClose, onSave }: {
  open: boolean; subjects: StudySubject[]; onClose: () => void;
  onSave: (s: Omit<import('../../lib/types').StudySession, 'id'>) => void;
}) {
  const [subjectId, setSubjectId] = useState(subjects[0]?.id || '');
  const [duration, setDuration] = useState('30');

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">Add Study Session</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4">
          {subjects.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">Add a subject first</p>
          ) : (
            <>
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-400">Subject</label>
                <div className="space-y-1">
                  {subjects.map((s) => (
                    <button key={s.id} onClick={() => setSubjectId(s.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                        subjectId === s.id ? 'bg-primary-600/20 text-primary-400 border border-primary-600/40' : 'bg-slate-800 text-slate-300'}`}>
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }} />{s.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Duration (minutes)</label><input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="30" className="input-field" /></div>
            </>
          )}
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!subjectId) return; onSave({ subjectId, duration: +duration || 30, completed: false, date: today() }); onClose(); }}
            disabled={!subjectId} className="flex-1 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">Add Session</button>
        </div>
      </div>
    </div>
  );
}
