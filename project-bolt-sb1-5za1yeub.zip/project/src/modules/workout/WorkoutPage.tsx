import { useState } from 'react';
import { Plus, Dumbbell, Flame, Clock, Trash2, ChevronDown, ChevronUp, TrendingUp } from 'lucide-react';
import { useWorkoutStore } from '../../store/useWorkoutStore';
import Badge from '../../components/ui/Badge';
import { EXERCISE_PRESETS } from '../../lib/constants';
import { today, relativeDay } from '../../lib/date';
import type { Workout, ExerciseEntry } from '../../lib/types';

const WORKOUT_TYPES: { value: Workout['type']; label: string }[] = [
  { value: 'strength', label: 'Strength' },
  { value: 'cardio', label: 'Cardio' },
  { value: 'flexibility', label: 'Flexibility' },
  { value: 'sports', label: 'Sports' },
];

const TYPE_BADGE_VARIANT: Record<string, 'primary' | 'warning' | 'accent' | 'error'> = {
  strength: 'primary', cardio: 'warning', flexibility: 'accent', sports: 'error',
};

export default function WorkoutPage() {
  const { workouts, addWorkout, deleteWorkout, todayWorkouts, weekCalories, weekWorkouts, weekMinutes } = useWorkoutStore();
  const [showForm, setShowForm] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const todayList = todayWorkouts();
  const weekList = weekWorkouts();
  const weekCals = weekCalories();
  const weekMins = weekMinutes();
  const todayCals = todayList.reduce((s, w) => s + w.caloriesBurned, 0);
  const todayMins = todayList.reduce((s, w) => s + w.duration, 0);
  const recentWorkouts = [...workouts].reverse().slice(0, 30);

  return (
    <div className="h-full overflow-y-auto pb-4 scrollbar-hide">
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-warning-600 flex items-center justify-center"><Dumbbell size={20} className="text-white" /></div>
          <div><h1 className="text-xl font-bold text-slate-100">Workout</h1><p className="text-xs text-slate-500">Track your activity</p></div>
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="px-4 mt-2">
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2 mb-3"><TrendingUp size={14} />This Week</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center"><p className="text-2xl font-bold text-primary-400">{weekMins}</p><p className="text-xs text-slate-500">minutes</p></div>
            <div className="text-center"><p className="text-2xl font-bold text-warning-400">{weekCals}</p><p className="text-xs text-slate-500">kcal burned</p></div>
            <div className="text-center"><p className="text-2xl font-bold text-accent-400">{weekList.length}</p><p className="text-xs text-slate-500">workouts</p></div>
          </div>
        </div>
      </div>

      {/* Today */}
      <div className="px-4 mt-4">
        <p className="section-title mb-2">Today</p>
        {todayList.length === 0 ? (
          <div className="flex flex-col items-center py-12 text-center">
            <Dumbbell size={40} className="text-slate-700 mb-3" />
            <p className="text-base font-semibold text-slate-500">No workouts today</p>
            <p className="text-sm text-slate-600 mt-1">Log a workout to track progress</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="card text-center py-3"><p className="text-lg font-bold text-warning-400 flex items-center justify-center gap-1"><Flame size={16} />{todayCals}</p><p className="text-xs text-slate-500">kcal burned</p></div>
              <div className="card text-center py-3"><p className="text-lg font-bold text-primary-400 flex items-center justify-center gap-1"><Clock size={16} />{todayMins}</p><p className="text-xs text-slate-500">minutes</p></div>
            </div>
            <div className="space-y-2">
              {todayList.map((w) => <WorkoutItem key={w.id} workout={w} onDelete={deleteWorkout} />)}
            </div>
          </>
        )}
      </div>

      {/* History */}
      <div className="px-4 mt-6">
        <button onClick={() => setShowHistory(!showHistory)} className="w-full flex items-center justify-between mb-2">
          <p className="section-title">History</p>
          {showHistory ? <ChevronUp size={14} className="text-slate-500" /> : <ChevronDown size={14} className="text-slate-500" />}
        </button>
        {showHistory && (
          <div className="space-y-2">
            {recentWorkouts.length === 0 ? <p className="text-sm text-slate-500 text-center py-4">No workout history yet</p>
              : recentWorkouts.map((w) => <WorkoutItem key={w.id} workout={w} onDelete={deleteWorkout} />)}
          </div>
        )}
      </div>

      {/* FAB */}
      <button onClick={() => setShowForm(true)}
        className="fixed bottom-20 right-4 w-14 h-14 bg-warning-600 hover:bg-warning-500 rounded-full shadow-lg shadow-warning-600/30 flex items-center justify-center transition-colors z-30">
        <Plus size={24} className="text-white" />
      </button>

      <WorkoutFormModal open={showForm} onClose={() => setShowForm(false)} onSave={addWorkout} />
    </div>
  );
}

function WorkoutItem({ workout, onDelete }: { workout: Workout; onDelete: (id: string) => void }) {
  const dateLabel = workout.timestamp.startsWith(today()) ? 'Today' : relativeDay(workout.timestamp.split('T')[0]);
  return (
    <div className="card flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-slate-200">{workout.name}</p>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <Badge variant={TYPE_BADGE_VARIANT[workout.type] || 'primary'}>{workout.type}</Badge>
          <span className="text-xs text-slate-500 flex items-center gap-1"><Clock size={10} />{workout.duration} min</span>
          <span className="text-xs text-slate-500 flex items-center gap-1"><Flame size={10} />{workout.caloriesBurned} kcal</span>
        </div>
        {workout.exercises.length > 0 && <p className="text-xs text-slate-600 mt-1">{workout.exercises.map((e) => e.name).join(', ')}</p>}
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-500">{dateLabel}</span>
        <button onClick={() => onDelete(workout.id)} className="p-1 rounded hover:bg-slate-700 text-slate-600 hover:text-error-400"><Trash2 size={14} /></button>
      </div>
    </div>
  );
}

function WorkoutFormModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (w: Omit<Workout, 'id' | 'timestamp'>) => void }) {
  const [name, setName] = useState('');
  const [type, setType] = useState<Workout['type']>('strength');
  const [duration, setDuration] = useState('');
  const [calories, setCalories] = useState('');
  const [exercises, setExercises] = useState<ExerciseEntry[]>([]);
  const [exerciseSearch, setExerciseSearch] = useState('');

  const presets = Object.entries(EXERCISE_PRESETS).filter(([k]) => k.toLowerCase().includes(exerciseSearch.toLowerCase()));

  const reset = () => { setName(''); setType('strength'); setDuration(''); setCalories(''); setExercises([]); setExerciseSearch(''); };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { reset(); onClose(); }} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">Log Workout</h2>
          <button onClick={() => { reset(); onClose(); }} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto">
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Workout name</label><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Upper Body Push" className="input-field" /></div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Type</label>
            <div className="grid grid-cols-4 gap-1">
              {WORKOUT_TYPES.map((t) => (
                <button key={t.value} onClick={() => setType(t.value)}
                  className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-colors ${type === t.value ? 'bg-primary-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Duration (min)</label><input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="45" className="input-field" /></div>
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Calories burned</label><input type="number" value={calories} onChange={(e) => setCalories(e.target.value)} placeholder="300" className="input-field" /></div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Add exercise</label>
            <input value={exerciseSearch} onChange={(e) => setExerciseSearch(e.target.value)} placeholder="Search exercises..." className="input-field" />
            {presets.length > 0 && exerciseSearch && (
              <div className="mt-1 max-h-28 overflow-y-auto bg-slate-800 rounded-lg border border-slate-700">
                {presets.slice(0, 5).map(([key, data]) => (
                  <button key={key} onClick={() => { setExercises([...exercises, { name: key }]); setExerciseSearch(''); }}
                    className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 flex justify-between">
                    <span>{key}</span><span className="text-xs text-slate-500">{data.caloriesPerMinute} kcal/min</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          {exercises.length > 0 && (
            <div className="space-y-1">
              {exercises.map((ex, i) => (
                <div key={i} className="flex items-center justify-between bg-slate-800/50 rounded-lg px-3 py-2">
                  <span className="text-sm text-slate-300">{ex.name}</span>
                  <button onClick={() => setExercises(exercises.filter((_, j) => j !== i))} className="text-slate-500 hover:text-error-400"><Trash2 size={14} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={() => { reset(); onClose(); }} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!name.trim()) return; onSave({ name: name.trim(), type, duration: +duration || 0, caloriesBurned: +calories || 0, exercises }); reset(); onClose(); }}
            disabled={!name.trim()} className="flex-1 px-4 py-2.5 bg-warning-600 hover:bg-warning-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">Log Workout</button>
        </div>
      </div>
    </div>
  );
}
