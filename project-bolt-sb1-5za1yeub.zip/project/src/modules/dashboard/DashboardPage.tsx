import { CheckSquare, Utensils, Dumbbell, BookOpen, TrendingUp, Flame, Target, Clock } from 'lucide-react';
import { useTaskStore } from '../../store/useTaskStore';
import { useDietStore } from '../../store/useDietStore';
import { useWorkoutStore } from '../../store/useWorkoutStore';
import { useStudyStore } from '../../store/useStudyStore';
import ProgressRing from '../../components/ui/ProgressRing';
import { today, last7Days } from '../../lib/date';

export default function DashboardPage() {
  const { tasks } = useTaskStore();
  const { todayMacros, weightEntries } = useDietStore();
  const { workouts } = useWorkoutStore();
  const { sessions, weekMinutes: studyWeekMins, streakDays } = useStudyStore();

  const todayTasks = tasks.filter((t) => t.dueDate === today() || (!t.dueDate && !t.completed));
  const completedTasks = todayTasks.filter((t) => t.completed).length;
  const totalTasks = todayTasks.length;
  const taskProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const macros = todayMacros();
  const calorieGoal = 2200;
  const calorieProgress = Math.min(100, Math.round((macros.calories / calorieGoal) * 100));
  const latestWeight = weightEntries.length > 0 ? weightEntries[weightEntries.length - 1] : null;

  const todayWorkouts = workouts.filter((w) => w.timestamp.startsWith(today()));
  const todayCals = todayWorkouts.reduce((s, w) => s + w.caloriesBurned, 0);
  const todayMins = todayWorkouts.reduce((s, w) => s + w.duration, 0);

  const todaySessions = sessions.filter((s) => s.date === today());
  const completedSessions = todaySessions.filter((s) => s.completed).length;
  const totalSessions = todaySessions.length;
  const studyProgress = totalSessions > 0 ? Math.round((completedSessions / totalSessions) * 100) : 0;

  const streak = streakDays();
  const studyWeek = studyWeekMins();

  return (
    <div className="h-full overflow-y-auto pb-4 scrollbar-hide">
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center"><TrendingUp size={20} className="text-white" /></div>
          <div><h1 className="text-xl font-bold text-slate-100">GrowthApp</h1><p className="text-xs text-slate-500">Today — {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</p></div>
        </div>
      </div>

      {/* Streak Banner */}
      {streak > 0 && (
        <div className="px-4 mt-2">
          <div className="card bg-gradient-to-r from-primary-900/40 to-accent-900/40 border-primary-700/30">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary-600/30 rounded-xl flex items-center justify-center"><Flame size={20} className="text-primary-400" /></div>
              <div><p className="text-lg font-bold text-slate-100">{streak} Day Streak</p><p className="text-xs text-slate-500">Keep going, you're building momentum!</p></div>
            </div>
          </div>
        </div>
      )}

      {/* Overview Rings */}
      <div className="px-4 mt-4">
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-400 mb-3">Today's Overview</h3>
          <div className="grid grid-cols-4 gap-2">
            <ProgressRing progress={taskProgress} size={72} strokeWidth={5} color="#3b82f6" label={`${completedTasks}/${totalTasks}`} sublabel="tasks" />
            <ProgressRing progress={calorieProgress} size={72} strokeWidth={5} color="#f59e0b" label={`${macros.calories}`} sublabel="kcal" />
            <ProgressRing progress={Math.min(100, todayMins > 0 ? 100 : 0)} size={72} strokeWidth={5} color="#10b981" label={`${todayMins}`} sublabel="min active" />
            <ProgressRing progress={studyProgress} size={72} strokeWidth={5} color="#8b5cf6" label={`${completedSessions}/${totalSessions}`} sublabel="study" />
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-4 mt-4 grid grid-cols-2 gap-2">
        <div className="card flex items-center gap-3">
          <div className="w-9 h-9 bg-primary-600/20 rounded-lg flex items-center justify-center"><CheckSquare size={18} className="text-primary-400" /></div>
          <div><p className="text-sm font-semibold text-slate-200">{completedTasks} done</p><p className="text-xs text-slate-500">{totalTasks - completedTasks} remaining</p></div>
        </div>
        <div className="card flex items-center gap-3">
          <div className="w-9 h-9 bg-warning-600/20 rounded-lg flex items-center justify-center"><Utensils size={18} className="text-warning-400" /></div>
          <div><p className="text-sm font-semibold text-slate-200">{macros.protein}g protein</p><p className="text-xs text-slate-500">{macros.calories} kcal today</p></div>
        </div>
        <div className="card flex items-center gap-3">
          <div className="w-9 h-9 bg-accent-600/20 rounded-lg flex items-center justify-center"><Dumbbell size={18} className="text-accent-400" /></div>
          <div><p className="text-sm font-semibold text-slate-200">{todayMins} min</p><p className="text-xs text-slate-500">{todayCals} kcal burned</p></div>
        </div>
        <div className="card flex items-center gap-3">
          <div className="w-9 h-9 bg-purple-600/20 rounded-lg flex items-center justify-center"><BookOpen size={18} className="text-purple-400" /></div>
          <div><p className="text-sm font-semibold text-slate-200">{completedSessions} done</p><p className="text-xs text-slate-500">{studyWeek} min this week</p></div>
        </div>
      </div>

      {/* Weight Progress */}
      {latestWeight && (
        <div className="px-4 mt-4">
          <div className="card">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3"><Target size={18} className="text-accent-400" />
                <div><p className="text-sm font-semibold text-slate-200">Weight: {latestWeight.weight} kg</p><p className="text-xs text-slate-500">Goal: {latestWeight.goalWeight} kg</p></div>
              </div>
              <ProgressRing progress={Math.max(0, Math.min(100, Math.round(((latestWeight.weight - latestWeight.goalWeight) / (Math.max(latestWeight.weight, latestWeight.goalWeight) - latestWeight.goalWeight + 0.1)) * 100)))} size={56} strokeWidth={4} color="#10b981" />
            </div>
          </div>
        </div>
      )}

      {/* Weekly Activity */}
      <div className="px-4 mt-4">
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2"><TrendingUp size={14} />Weekly Activity</h3>
          <div className="flex items-end justify-between gap-1 h-24">
            {last7Days().map((day) => {
              const mins = workouts.filter((w) => w.timestamp.startsWith(day)).reduce((s, w) => s + w.duration, 0);
              const height = Math.max(4, Math.min(100, mins > 0 ? Math.round((mins / 90) * 100) : 0));
              const isToday = day === today();
              return (
                <div key={day} className="flex flex-col items-center gap-1 flex-1">
                  <div className={`w-full rounded-t-sm transition-all ${isToday ? 'bg-primary-500' : 'bg-slate-700'}`} style={{ height: `${height}%` }} />
                  <span className={`text-[10px] ${isToday ? 'text-primary-400 font-semibold' : 'text-slate-600'}`}>
                    {new Date(day).toLocaleDateString('en-US', { weekday: 'narrow' })}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Upcoming Tasks */}
      <div className="px-4 mt-4 mb-4">
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-400 mb-2 flex items-center gap-2"><Clock size={14} />Upcoming Tasks</h3>
          {todayTasks.filter((t) => !t.completed).slice(0, 4).map((t) => (
            <div key={t.id} className="flex items-center gap-2 py-1.5 border-b border-slate-800 last:border-0">
              <div className="w-1.5 h-1.5 rounded-full bg-primary-500" />
              <span className="text-sm text-slate-300 truncate">{t.title}</span>
              {t.dueTime && <span className="badge-primary text-[10px]">{t.dueTime}</span>}
            </div>
          ))}
          {todayTasks.filter((t) => !t.completed).length === 0 && <p className="text-sm text-slate-500 py-2">All caught up!</p>}
        </div>
      </div>
    </div>
  );
}
