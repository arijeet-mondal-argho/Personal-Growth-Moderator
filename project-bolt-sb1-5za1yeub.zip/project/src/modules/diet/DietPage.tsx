import { useState } from 'react';
import { Plus, Utensils, Trash2, Target, ChevronDown, ChevronUp, Flame, Beef, Wheat, Droplets } from 'lucide-react';
import { useDietStore } from '../../store/useDietStore';
import ProgressRing from '../../components/ui/ProgressRing';
import Badge from '../../components/ui/Badge';
import { MACRO_PRESETS } from '../../lib/constants';
import { today, relativeDay } from '../../lib/date';
import type { FoodEntry } from '../../lib/types';

const MEALS: { value: FoodEntry['meal']; label: string }[] = [
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'lunch', label: 'Lunch' },
  { value: 'dinner', label: 'Dinner' },
  { value: 'snack', label: 'Snack' },
];

export default function DietPage() {
  const { weightEntries, addFoodEntry, deleteFoodEntry, addWeightEntry, todayMacros, todayEntries } = useDietStore();
  const [showFoodForm, setShowFoodForm] = useState(false);
  const [showWeightForm, setShowWeightForm] = useState(false);
  const [expandedMeal, setExpandedMeal] = useState<FoodEntry['meal'] | null>('breakfast');

  const macros = todayMacros();
  const entries = todayEntries();
  const latestWeight = weightEntries.length > 0 ? weightEntries[weightEntries.length - 1] : null;
  const calorieGoal = 2200;
  const calorieProgress = Math.min(100, Math.round((macros.calories / calorieGoal) * 100));
  const weightProgress = latestWeight
    ? Math.max(0, Math.min(100, Math.round(((latestWeight.weight - latestWeight.goalWeight) / (Math.max(latestWeight.weight, latestWeight.goalWeight) - latestWeight.goalWeight + 0.1)) * 100)))
    : 0;

  return (
    <div className="h-full overflow-y-auto pb-4 scrollbar-hide">
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-600 flex items-center justify-center"><Utensils size={20} className="text-white" /></div>
          <div><h1 className="text-xl font-bold text-slate-100">Diet</h1><p className="text-xs text-slate-500">Track your nutrition</p></div>
        </div>
      </div>

      {/* Macro Overview */}
      <div className="px-4 mt-2">
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-slate-300">Today's Macros</h3>
            <span className="text-xs text-slate-500">{macros.calories} / {calorieGoal} kcal</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <ProgressRing progress={calorieProgress} size={64} strokeWidth={5} color="#f59e0b" label={`${macros.calories}`} sublabel="kcal" />
            <ProgressRing progress={Math.min(100, Math.round((macros.protein / 150) * 100))} size={64} strokeWidth={5} color="#ef4444" label={`${macros.protein}g`} sublabel="protein" />
            <ProgressRing progress={Math.min(100, Math.round((macros.carbs / 250) * 100))} size={64} strokeWidth={5} color="#3b82f6" label={`${macros.carbs}g`} sublabel="carbs" />
            <ProgressRing progress={Math.min(100, Math.round((macros.fats / 70) * 100))} size={64} strokeWidth={5} color="#10b981" label={`${macros.fats}g`} sublabel="fats" />
          </div>
        </div>
      </div>

      {/* Weight Goal */}
      <div className="px-4 mt-4">
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2"><Target size={14} />Weight Goal</h3>
              {latestWeight ? (
                <><p className="text-2xl font-bold text-slate-100 mt-1">{latestWeight.weight} kg</p>
                <p className="text-xs text-slate-500">Goal: {latestWeight.goalWeight} kg by {relativeDay(latestWeight.targetDate)}</p></>
              ) : <p className="text-xs text-slate-500 mt-1">Set a weight goal to track progress</p>}
            </div>
            {latestWeight && <ProgressRing progress={weightProgress} size={70} strokeWidth={5} color="#10b981" label={`${weightProgress}%`} />}
          </div>
          <button onClick={() => setShowWeightForm(true)} className="mt-2 px-3 py-1.5 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-lg transition-colors">
            {latestWeight ? 'Update weight' : 'Set weight goal'}
          </button>
        </div>
      </div>

      {/* Today's Meals */}
      <div className="px-4 mt-4">
        <p className="section-title mb-2">Today's Meals</p>
        {entries.length === 0 ? (
          <div className="flex flex-col items-center py-12 text-center">
            <Utensils size={40} className="text-slate-700 mb-3" />
            <p className="text-base font-semibold text-slate-500">No meals logged today</p>
            <p className="text-sm text-slate-600 mt-1">Add your first meal</p>
          </div>
        ) : (
          MEALS.map((meal) => {
            const mealEntries = entries.filter((e) => e.meal === meal.value);
            if (mealEntries.length === 0 && expandedMeal !== meal.value) return null;
            const isExpanded = expandedMeal === meal.value;
            const mealTotal = mealEntries.reduce((sum, e) => sum + e.calories, 0);
            return (
              <div key={meal.value} className="mb-2">
                <button onClick={() => setExpandedMeal(isExpanded ? null : meal.value)} className="w-full flex items-center justify-between py-2 px-1">
                  <span className="text-sm font-medium text-slate-300">{meal.label}</span>
                  <span className="flex items-center gap-2 text-xs text-slate-500">
                    {mealTotal > 0 && `${mealTotal} kcal`}
                    {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </span>
                </button>
                {isExpanded && (
                  <div className="space-y-1.5">
                    {mealEntries.map((e) => (
                      <div key={e.id} className="flex items-center justify-between bg-slate-800/50 rounded-lg px-3 py-2">
                        <div>
                          <p className="text-sm text-slate-200">{e.name}</p>
                          <div className="flex gap-3 mt-0.5">
                            <span className="text-xs text-slate-500 flex items-center gap-1"><Beef size={10} />{e.protein}g</span>
                            <span className="text-xs text-slate-500 flex items-center gap-1"><Wheat size={10} />{e.carbs}g</span>
                            <span className="text-xs text-slate-500 flex items-center gap-1"><Droplets size={10} />{e.fats}g</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="warning"><Flame size={10} className="mr-1" />{e.calories}</Badge>
                          <button onClick={() => deleteFoodEntry(e.id)} className="p-1 rounded hover:bg-slate-700 text-slate-600 hover:text-error-400"><Trash2 size={14} /></button>
                        </div>
                      </div>
                    ))}
                    {mealEntries.length === 0 && <p className="text-xs text-slate-600 py-1">No items yet</p>}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* FAB */}
      <button onClick={() => setShowFoodForm(true)}
        className="fixed bottom-20 right-4 w-14 h-14 bg-accent-600 hover:bg-accent-500 rounded-full shadow-lg shadow-accent-600/30 flex items-center justify-center transition-colors z-30">
        <Plus size={24} className="text-white" />
      </button>

      <FoodFormModal open={showFoodForm} onClose={() => setShowFoodForm(false)} onSave={addFoodEntry} />
      <WeightFormModal open={showWeightForm} onClose={() => setShowWeightForm(false)} onSave={addWeightEntry} />
    </div>
  );
}

function FoodFormModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (e: Omit<FoodEntry, 'id' | 'timestamp'>) => void }) {
  const [name, setName] = useState('');
  const [meal, setMeal] = useState<FoodEntry['meal']>('lunch');
  const [protein, setProtein] = useState('0');
  const [carbs, setCarbs] = useState('0');
  const [fats, setFats] = useState('0');
  const [calories, setCalories] = useState('0');
  const [presetSearch, setPresetSearch] = useState('');

  const presets = Object.entries(MACRO_PRESETS).filter(([k]) => k.toLowerCase().includes(presetSearch.toLowerCase()));

  const applyPreset = (key: string) => {
    const p = MACRO_PRESETS[key];
    setName(key); setProtein(String(p.protein)); setCarbs(String(p.carbs));
    setFats(String(p.fats)); setCalories(String(p.calories)); setPresetSearch('');
  };

  const reset = () => { setName(''); setMeal('lunch'); setProtein('0'); setCarbs('0'); setFats('0'); setCalories('0'); setPresetSearch(''); };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { reset(); onClose(); }} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">Log Meal</h2>
          <button onClick={() => { reset(); onClose(); }} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Search food</label>
            <input value={presetSearch} onChange={(e) => setPresetSearch(e.target.value)} placeholder="Chicken, Rice, Egg..." className="input-field" />
            {presets.length > 0 && presetSearch && (
              <div className="mt-1 max-h-32 overflow-y-auto bg-slate-800 rounded-lg border border-slate-700">
                {presets.slice(0, 6).map(([key]) => (
                  <button key={key} onClick={() => applyPreset(key)} className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700">{key}</button>
                ))}
              </div>
            )}
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Food name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Chicken Breast" className="input-field" />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Meal</label>
            <div className="grid grid-cols-4 gap-1">
              {MEALS.map((m) => (
                <button key={m.value} onClick={() => setMeal(m.value)}
                  className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-colors ${meal === m.value ? 'bg-primary-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Protein (g)</label><input type="number" value={protein} onChange={(e) => setProtein(e.target.value)} className="input-field" /></div>
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Carbs (g)</label><input type="number" value={carbs} onChange={(e) => setCarbs(e.target.value)} className="input-field" /></div>
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Fats (g)</label><input type="number" value={fats} onChange={(e) => setFats(e.target.value)} className="input-field" /></div>
            <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Calories</label><input type="number" value={calories} onChange={(e) => setCalories(e.target.value)} className="input-field" /></div>
          </div>
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={() => { reset(); onClose(); }} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!name.trim()) return; onSave({ name: name.trim(), meal, protein: +protein, carbs: +carbs, fats: +fats, calories: +calories }); reset(); onClose(); }}
            disabled={!name.trim()} className="flex-1 px-4 py-2.5 bg-accent-600 hover:bg-accent-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">
            Log Meal
          </button>
        </div>
      </div>
    </div>
  );
}

function WeightFormModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (w: number, g: number, t: string) => void }) {
  const [weight, setWeight] = useState('');
  const [goalWeight, setGoalWeight] = useState('');
  const [targetDate, setTargetDate] = useState('');

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">Weight Goal</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4">
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Current weight (kg)</label><input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="70" className="input-field" /></div>
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Goal weight (kg)</label><input type="number" value={goalWeight} onChange={(e) => setGoalWeight(e.target.value)} placeholder="65" className="input-field" /></div>
          <div className="space-y-1"><label className="text-xs font-medium text-slate-400">Target date</label><input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} className="input-field" /></div>
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!weight || !goalWeight) return; onSave(+weight, +goalWeight, targetDate || today()); onClose(); }}
            disabled={!weight || !goalWeight} className="flex-1 px-4 py-2.5 bg-accent-600 hover:bg-accent-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">Save</button>
        </div>
      </div>
    </div>
  );
}
