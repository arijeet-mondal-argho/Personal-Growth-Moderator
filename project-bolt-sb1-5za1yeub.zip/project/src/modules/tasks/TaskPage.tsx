import { useState, useEffect } from 'react';
import { Plus, CheckSquare, Calendar, Clock, Repeat, MoreHorizontal, Trash2, Edit3 } from 'lucide-react';
import { useTaskStore } from '../../store/useTaskStore';
import { today, relativeDay, isToday, isPast } from '../../lib/date';
import type { Task } from '../../lib/types';

const RECURRING_OPTIONS: { value: Task['recurring']; label: string }[] = [
  { value: 'none', label: 'No repeat' },
  { value: 'daily', label: 'Every day' },
  { value: 'weekdays', label: 'Weekdays' },
  { value: 'weekly', label: 'Every week' },
];

export default function TaskPage() {
  const { tasks, addTask, updateTask, deleteTask, toggleTask, generateRecurring } = useTaskStore();
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);

  useEffect(() => { generateRecurring(); }, [generateRecurring]);

  const todayTasks = tasks.filter((t) => t.dueDate === today() || (!t.dueDate && !t.completed));
  const overdueTasks = tasks.filter((t) => t.dueDate && isPast(t.dueDate) && !isToday(t.dueDate) && !t.completed);
  const upcomingTasks = tasks.filter((t) => t.dueDate && !isToday(t.dueDate) && !isPast(t.dueDate) && !t.completed);
  const completedToday = tasks.filter((t) => t.completed && t.completedAt?.startsWith(today()));

  const completedCount = completedToday.length;
  const totalCount = todayTasks.filter((t) => !t.completed).length + completedCount;
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="h-full overflow-y-auto pb-4 scrollbar-hide">
      {/* Header */}
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
            <CheckSquare size={20} className="text-white" />
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-slate-100">My Tasks</h1>
            <p className="text-xs text-slate-500">{completedCount} of {totalCount} done today</p>
          </div>
        </div>
        <div className="mt-3 h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-primary-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      {/* Overdue */}
      {overdueTasks.length > 0 && (
        <section className="px-4 mt-4">
          <p className="section-title mb-2">Overdue</p>
          <div className="space-y-2">
            {overdueTasks.map((t) => <TaskItem key={t.id} task={t} onToggle={toggleTask} onEdit={(tk) => { setEditingTask(tk); setShowForm(true); }} onDelete={deleteTask} menuOpenId={menuOpenId} setMenuOpenId={setMenuOpenId} />)}
          </div>
        </section>
      )}

      {/* Today */}
      <section className="px-4 mt-4">
        <p className="section-title mb-2">Today</p>
        {todayTasks.length === 0 && overdueTasks.length === 0 ? (
          <div className="flex flex-col items-center py-16 text-center">
            <CheckSquare size={44} className="text-slate-700 mb-3" />
            <p className="text-base font-semibold text-slate-500">No tasks today</p>
            <p className="text-sm text-slate-600 mt-1">Tap + to add your first task</p>
          </div>
        ) : (
          <div className="space-y-2">
            {todayTasks.map((t) => <TaskItem key={t.id} task={t} onToggle={toggleTask} onEdit={(tk) => { setEditingTask(tk); setShowForm(true); }} onDelete={deleteTask} menuOpenId={menuOpenId} setMenuOpenId={setMenuOpenId} />)}
          </div>
        )}
      </section>

      {/* Upcoming */}
      {upcomingTasks.length > 0 && (
        <section className="px-4 mt-6">
          <p className="section-title mb-2">Upcoming</p>
          <div className="space-y-2">
            {upcomingTasks.map((t) => <TaskItem key={t.id} task={t} onToggle={toggleTask} onEdit={(tk) => { setEditingTask(tk); setShowForm(true); }} onDelete={deleteTask} menuOpenId={menuOpenId} setMenuOpenId={setMenuOpenId} />)}
          </div>
        </section>
      )}

      {/* Completed */}
      {completedToday.length > 0 && (
        <section className="px-4 mt-6">
          <p className="section-title mb-2">Completed</p>
          <div className="space-y-2">
            {completedToday.map((t) => <TaskItem key={t.id} task={t} onToggle={toggleTask} onEdit={(tk) => { setEditingTask(tk); setShowForm(true); }} onDelete={deleteTask} menuOpenId={menuOpenId} setMenuOpenId={setMenuOpenId} />)}
          </div>
        </section>
      )}

      {/* FAB */}
      <button onClick={() => { setEditingTask(null); setShowForm(true); }}
        className="fixed bottom-20 right-4 w-14 h-14 bg-primary-600 hover:bg-primary-500 active:bg-primary-700 rounded-full shadow-lg shadow-primary-600/30 flex items-center justify-center transition-colors z-30">
        <Plus size={24} className="text-white" />
      </button>

      <TaskFormModal open={showForm || !!editingTask} task={editingTask}
        onClose={() => { setShowForm(false); setEditingTask(null); }}
        onSave={(data) => { if (editingTask) updateTask(editingTask.id, data); else addTask(data); setShowForm(false); setEditingTask(null); }} />
    </div>
  );
}

function TaskItem({ task, onToggle, onEdit, onDelete, menuOpenId, setMenuOpenId }: {
  task: Task; onToggle: (id: string) => void; onEdit: (t: Task) => void;
  onDelete: (id: string) => void; menuOpenId: string | null; setMenuOpenId: (id: string | null) => void;
}) {
  const overdue = !!(task.dueDate && isPast(task.dueDate) && !isToday(task.dueDate) && !task.completed);
  const isMenuOpen = menuOpenId === task.id;

  return (
    <div className="card flex items-start gap-3 group">
      <button onClick={() => onToggle(task.id)}
        className={`mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all ${
          task.completed ? 'bg-primary-600 border-primary-600' : 'border-slate-600 hover:border-primary-400 active:scale-90'}`}>
        {task.completed && <svg viewBox="0 0 12 12" className="w-3 h-3 text-white"><path d="M2 6l3 3 5-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>}
      </button>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium ${task.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>{task.title}</p>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          {task.dueDate && <span className={`flex items-center gap-1 text-xs ${overdue ? 'text-error-400' : 'text-slate-500'}`}><Calendar size={12} />{relativeDay(task.dueDate)}</span>}
          {task.dueTime && <span className="flex items-center gap-1 text-xs text-slate-500"><Clock size={12} />{task.dueTime}</span>}
          {task.recurring !== 'none' && <span className="badge-accent"><Repeat size={10} className="mr-1" />{task.recurring}</span>}
          {overdue && <span className="badge-error">Overdue</span>}
        </div>
      </div>
      <div className="relative">
        <button onClick={() => setMenuOpenId(isMenuOpen ? null : task.id)} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-500 opacity-60 group-hover:opacity-100">
          <MoreHorizontal size={16} />
        </button>
        {isMenuOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setMenuOpenId(null)} />
            <div className="absolute right-0 top-8 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-20 py-1 w-32">
              <button onClick={() => { onEdit(task); setMenuOpenId(null); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:bg-slate-700"><Edit3 size={14} />Edit</button>
              <button onClick={() => { onDelete(task.id); setMenuOpenId(null); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-error-400 hover:bg-slate-700"><Trash2 size={14} />Delete</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function TaskFormModal({ open, task, onClose, onSave }: {
  open: boolean; task: Task | null; onClose: () => void;
  onSave: (data: Omit<Task, 'id' | 'completed' | 'completedAt' | 'createdAt'>) => void;
}) {
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState(today());
  const [dueTime, setDueTime] = useState('');
  const [recurring, setRecurring] = useState<Task['recurring']>('none');

  useEffect(() => {
    if (open) {
      if (task) { setTitle(task.title); setDueDate(task.dueDate || today()); setDueTime(task.dueTime || ''); setRecurring(task.recurring); }
      else { setTitle(''); setDueDate(today()); setDueTime(''); setRecurring('none'); }
    }
  }, [task, open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-slate-900 border border-slate-800 w-full max-w-lg mx-4 mb-4 sm:mb-0 rounded-2xl shadow-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">{task ? 'Edit Task' : 'New Task'}</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <svg viewBox="0 0 20 20" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" /></svg>
          </button>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Task title</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What do you need to do?" className="input-field" autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-400">Due date</label>
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="input-field" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-400">Due time</label>
              <input type="time" value={dueTime} onChange={(e) => setDueTime(e.target.value)} className="input-field" />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400">Repeat</label>
            <div className="grid grid-cols-2 gap-2">
              {RECURRING_OPTIONS.map((opt) => (
                <button key={opt.value} onClick={() => setRecurring(opt.value)}
                  className={`px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    recurring === opt.value ? 'bg-primary-600 text-white shadow-md shadow-primary-600/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-3">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm transition-colors">Cancel</button>
          <button onClick={() => { if (!title.trim()) return; onSave({ title: title.trim(), dueDate: dueDate || null, dueTime: dueTime || null, recurring }); }}
            disabled={!title.trim()} className="flex-1 px-4 py-2.5 bg-primary-600 hover:bg-primary-500 text-white font-medium rounded-lg text-sm transition-colors disabled:opacity-40">
            {task ? 'Update' : 'Add Task'}
          </button>
        </div>
      </div>
    </div>
  );
}
