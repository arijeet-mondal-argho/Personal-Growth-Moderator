import { useTaskStore } from '../store/useTaskStore';
import { useDietStore } from '../store/useDietStore';
import { useWorkoutStore } from '../store/useWorkoutStore';
import { useStudyStore } from '../store/useStudyStore';
import { today } from '../lib/date';
import type { Language } from '../lib/types';

export interface AppDataContext {
  todayTasks: { completed: number; total: number };
  macros: { protein: number; carbs: number; fats: number; calories: number };
  todayWorkouts: { count: number; minutes: number; calories: number };
  studyStreak: number;
  studyWeekMinutes: number;
  weightGoal: { current: number; target: number } | null;
}

export function getAppData(): AppDataContext {
  const tasks = useTaskStore.getState().tasks;
  const todayTasksList = tasks.filter((t) => t.dueDate === today() || !t.dueDate);
  const completedTasks = todayTasksList.filter((t) => t.completed).length;
  const macros = useDietStore.getState().todayMacros();
  const workouts = useWorkoutStore.getState().todayWorkouts();
  const study = useStudyStore.getState();
  const weightEntries = useDietStore.getState().weightEntries;
  const latestWeight = weightEntries.length > 0 ? weightEntries[weightEntries.length - 1] : null;

  return {
    todayTasks: { completed: completedTasks, total: todayTasksList.length },
    macros,
    todayWorkouts: {
      count: workouts.length,
      minutes: workouts.reduce((s, w) => s + w.duration, 0),
      calories: workouts.reduce((s, w) => s + w.caloriesBurned, 0),
    },
    studyStreak: study.streakDays(),
    studyWeekMinutes: study.weekMinutes(),
    weightGoal: latestWeight ? { current: latestWeight.weight, target: latestWeight.goalWeight } : null,
  };
}

export function getContextualAddendum(intent: string, data: AppDataContext, lang: Language): string {
  const parts: string[] = [];
  if (intent === 'diet' && data.macros.calories > 0) {
    if (lang === 'en') parts.push(`Based on your logs today: ${data.macros.protein}g protein, ${data.macros.calories} kcal.`);
    else if (lang === 'bn') parts.push(`আজকের লগ: ${data.macros.protein}g প্রোটিন, ${data.macros.calories} kcal.`);
    else parts.push(`Ajer log: ${data.macros.protein}g protein, ${data.macros.calories} kcal.`);
  }
  if (intent === 'workout' && data.todayWorkouts.count > 0) {
    if (lang === 'en') parts.push(`You've logged ${data.todayWorkouts.minutes} minutes of exercise today. Keep it up!`);
    else if (lang === 'bn') parts.push(`আজ ${data.todayWorkouts.minutes} মিনিট ব্যায়াম লগ করেছেন!`);
    else parts.push(`Aj ${data.todayWorkouts.minutes} minut byayam log korchen!`);
  }
  if (intent === 'study' && data.studyStreak > 0) {
    if (lang === 'en') parts.push(`You have a ${data.studyStreak}-day study streak!`);
    else if (lang === 'bn') parts.push(`আপনার ${data.studyStreak} দিনের স্ট্রিক আছে!`);
    else parts.push(`Apnar ${data.studyStreak} diner streak achhe!`);
  }
  return parts.join(' ');
}
