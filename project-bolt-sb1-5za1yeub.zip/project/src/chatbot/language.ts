import type { Language } from '../lib/types';

const BANGLA_SCRIPT_RANGE = /[\u0980-\u09FF]/;

const BANGLISH_MAP: Record<string, string> = {
  ami: 'আমি', tumi: 'তুমি', apni: 'আপনি', kemon: 'কেমন', achho: 'আছো', acho: 'আছো',
  valo: 'ভালো', bhalo: 'ভালো', khabar: 'খাবার', khete: 'খেতে', hobe: 'হবে',
  pari: 'পারি', parbo: 'পারবো', kibhabe: 'কিভাবে', ki: 'কি', keno: 'কেন',
  kothay: 'কোথায়', koto: 'কত', din: 'দিন', gym: 'জিম', porbo: 'পড়বো',
  pora: 'পড়া', exam: 'পরীক্ষা', focus: 'ফোকাস', diet: 'ডায়েট', protein: 'প্রোটিন',
  weight: 'ওজন', barabo: 'বাড়াবো', komabo: 'কমাবো', korbo: 'করবো', korchhi: 'করছি',
  korchi: 'করছি', chai: 'চাই', chahi: 'চাই', lagbe: 'লাগবে', dorkar: 'দরকার',
  routine: 'রুটিন', tips: 'টিপস', health: 'স্বাস্থ্য', exercise: 'ব্যায়াম',
  byayam: 'ব্যায়াম', food: 'খাবার', meal: 'খাবার', sleep: 'ঘুম', ghum: 'ঘুম',
  water: 'পানি', pani: 'পানি', active: 'অ্যাক্টিভ', recall: 'রিকল', memory: 'মেমোরি',
  habit: 'অভ্যাস', abhyas: 'অভ্যাস', motivation: 'মোটিভেশন', energy: 'এনার্জি',
  tired: 'ক্লান্ত', klanto: 'ক্লান্ত', stress: 'স্ট্রেস', morning: 'সকাল',
  sokal: 'সকাল', night: 'রাত', rate: 'রাত', kal: 'কাল', aj: 'আজ', aaj: 'আজ',
};

export function detectLanguage(text: string): Language {
  if (BANGLA_SCRIPT_RANGE.test(text)) return 'bn';
  const lower = text.toLowerCase();
  const banglishWords = Object.keys(BANGLISH_MAP);
  const matchCount = banglishWords.filter((w) => lower.includes(w)).length;
  const wordCount = lower.split(/\s+/).length;
  if (wordCount > 0 && matchCount / wordCount > 0.3) return 'bnEn';
  return 'en';
}

export function normalizeBanglish(text: string): string {
  let result = text;
  for (const [banglish, bangla] of Object.entries(BANGLISH_MAP)) {
    const regex = new RegExp(`\\b${banglish}\\b`, 'gi');
    result = result.replace(regex, bangla);
  }
  return result;
}

export function getTextForAnalysis(text: string): string {
  const lang = detectLanguage(text);
  if (lang === 'bnEn') return normalizeBanglish(text);
  return text;
}
