import type { ChatIntent, ConfidenceLevel, Language } from '../lib/types';
import { DISCLAIMER } from './safety';

interface FormattedResponse {
  content: string;
  confidence: ConfidenceLevel;
  source: string;
  intent: ChatIntent;
  suggestions: string[];
}

export function formatResponse(
  template: string, lang: Language, intent: ChatIntent,
  confidence: ConfidenceLevel, source: string, contextualAddendum: string,
): FormattedResponse {
  let content = template;
  if (contextualAddendum) content = `${content}\n\n${contextualAddendum}`;
  if (['diet', 'workout'].includes(intent) && confidence !== 'unsafe') {
    content = `${content}\n\n_${DISCLAIMER[lang]}_`;
  }
  return { content, confidence, source, intent, suggestions: getSuggestions(intent, lang) };
}

function getSuggestions(intent: ChatIntent, lang: Language): string[] {
  const map: Record<ChatIntent, { en: string[]; bn: string[]; bnEn: string[] }> = {
    diet: { en: ['How much protein do I need?', 'Tips for healthy meals', 'How to stay hydrated'], bn: ['কতটুকু প্রোটিন দরকার?', 'স্বাস্থ্যকর খাবার', 'পানি কতটুকু খাবো'], bnEn: ['Kototuku protein dorkar?', 'Swasthyokor khabar', 'Pani kototuku khabo'] },
    workout: { en: ['Beginner workout plan', 'How often should I exercise?', 'Recovery tips'], bn: ['নতুনদের ব্যায়াম', 'কতটা ব্যায়াম করবো?', 'পুনরুদ্ধার টিপস'], bnEn: ['Notuder byayam', 'Kotota byayam korbo?', 'Punoruddhar tips'] },
    study: { en: ['What is active recall?', 'How to use spaced repetition?', 'Tips for exam prep'], bn: ['অ্যাক্টিভ রিকল কী?', 'ব্যবধান পুনরাবৃত্তি কীভাবে?', 'পরীক্ষার টিপস'], bnEn: ['Active recall ki?', 'Byabodhan punorabritti kibhabe?', 'Porikhar tips'] },
    productivity: { en: ['Morning routine tips', 'How to build habits', 'Time management'], bn: ['সকালের রুটিন', 'অভ্যাস গঠন', 'সময় ব্যবস্থাপনা'], bnEn: ['Sokaler routine', 'Abhyas gothon', 'Somoy byabosthapon'] },
    habits: { en: ['How to build a habit', 'Consistency tips', 'Track my progress'], bn: ['অভ্যাস গঠন কীভাবে', 'নিয়মিত থাকার টিপস', 'অগ্রগতি ট্র্যাক'], bnEn: ['Abhyas gothon kibhabe', 'Niyomit thakar tips', 'Oggroti track'] },
    routine: { en: ['Morning routine plan', 'Daily schedule tips', 'Evening routine'], bn: ['সকালের রুটিন', 'দৈনিক সূচি', 'সন্ধ্যার রুটিন'], bnEn: ['Sokaler routine', 'Dainik suchi', 'Sandhyar routine'] },
    reminders: { en: ['My tasks today', 'Set a recurring task'], bn: ['আজকের টাস্ক', 'পুনরাবৃত্ত টাস্ক'], bnEn: ['Ajker task', 'Punorabritto task'] },
    safety_escalation: { en: [], bn: [], bnEn: [] },
    general_help: { en: ['Diet tips', 'Study hacks', 'Workout advice'], bn: ['ডায়েট টিপস', 'পড়াশোনার কৌশল', 'ব্যায়াম পরামর্শ'], bnEn: ['Diet tips', 'Porashonar koushol', 'Byayam paramarsha'] },
    greeting: { en: ['Diet tips', 'Study hacks', 'Workout advice'], bn: ['ডায়েট টিপস', 'পড়াশোনার কৌশল', 'ব্যায়াম পরামর্শ'], bnEn: ['Diet tips', 'Porashonar koushol', 'Byayam paramarsha'] },
  };
  return map[intent]?.[lang] || map[intent]?.en || [];
}
