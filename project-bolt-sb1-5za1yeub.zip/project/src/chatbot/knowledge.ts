import type { ChatRule } from '../lib/types';

export const KNOWLEDGE_BASE: ChatRule[] = [
  {
    id: 'diet_fruits_veg', triggers: ['fruit', 'vegetable', 'ফল', 'সবজি', '5 a day'],
    intent: 'diet',
    responseTemplates: {
      en: 'WHO recommends at least 400g of fruits and vegetables per day (about 5 servings). Try adding one serving to each meal.',
      bn: 'বিশ্ব স্বাস্থ্য সংস্থা প্রতিদিন কমপক্ষে ৪০০ গ্রাম ফল ও সবজি খাওয়ার পরামর্শ দেয়। প্রতিটি খাবারে একটি পরিবেশন যোগ করার চেষ্টা করুন।',
      bnEn: 'WHO protidin komokeshe 400g fol o sobji khabar paramarsha dey. Protita khabare ekta poribeshon jog korar chesta korun.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'WHO Healthy Diet Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'diet_protein', triggers: ['protein', 'প্রোটিন', 'muscle food', 'how much protein'],
    intent: 'diet',
    responseTemplates: {
      en: 'For active adults building muscle, 1.6-2.2g of protein per kg of body weight per day is commonly recommended. Spread it across meals for better absorption.',
      bn: 'সক্রিয় প্রাপকদের জন্য প্রতিকেজি ওজনে প্রতিদিন ১.৬-২.২ গ্রাম প্রোটিন পরামর্শিত। ভালো শোষণের জন্য খাবার জুড়ে ছড়িয়ে দিন।',
      bnEn: 'Sokriyo proyoktoder jonno protikeji ojone protidin 1.6-2.2 gram protein paramarshito. Valo shorshoner jonno khabar jure choriye din.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'NIH / ACSM Protein Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'diet_weight_loss', triggers: ['weight loss', 'lose weight', 'ওজন কমানো', 'fat loss', 'calorie deficit'],
    intent: 'diet',
    responseTemplates: {
      en: 'NIH suggests gradual weight loss of about 1-2 pounds (0.5-1 kg) per week, typically requiring a roughly 500-calorie-per-day deficit. Crash diets can be harmful.',
      bn: 'NIH সপ্তাহে প্রায় ০.৫-১ কেজি ধীরে ধীরে ওজন কমানোর পরামর্শ দেয়, যার জন্য প্রতিদিন প্রায় ৫০০ ক্যালোরি ঘাটতি প্রয়োজন। দ্রুত ডায়েট ক্ষতিকর।',
      bnEn: 'NIH soptaje proksimo 0.5-1 kg dhire dhire ojon komanor paramarsha dey, jar jonno protidin proksimo 500 calorie ghati proyojon. Druto diet khotikar.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'NIH Weight Management Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'diet_hydration', triggers: ['water', 'hydrate', 'hydration', 'পানি', 'thirsty', 'তৃষ্ণা'],
    intent: 'diet',
    responseTemplates: {
      en: 'Mild dehydration can reduce cognitive function, increase fatigue, and worsen attention. Aim for at least 8 glasses (about 2 liters) of water per day, more if you exercise.',
      bn: 'হালকা পানিশূন্যতা জ্ঞানীয় কার্যক্ষমতা কমাতে পারে এবং ক্লান্তি বাড়াতে পারে। প্রতিদিন কমপক্ষে ৮ গ্লাস পানি পান করুন।',
      bnEn: 'Halka panishunyota jogniyo karkhomota komate pare ebong klanti barate pare. Protidin komokeshe 8 glass pani pan korun.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'NIH Hydration and Cognition Review', lastUpdated: '2024-01',
  },
  {
    id: 'workout_weekly', triggers: ['how much exercise', 'exercise per week', 'weekly workout', 'সপ্তাহিক ব্যায়াম'],
    intent: 'workout',
    responseTemplates: {
      en: 'WHO and CDC recommend at least 150 minutes of moderate-intensity activity per week, plus 2 days of muscle-strengthening. That is about 30 minutes, 5 days a week.',
      bn: 'WHO এবং CDC সপ্তাহে কমপক্ষে ১৫০ মিনিট মাঝারি-তীব্রতার কার্যকলাপ এবং ২ দিন পেশি শক্তিশালীকরণের পরামর্শ দেয়।',
      bnEn: 'WHO ebong CDC soptaje komokeshe 150 minut majhari-tibrotar karmokolap ebong 2 din peshi shoktishalikoroner paramarsha dey.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'WHO / CDC Physical Activity Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'workout_beginner', triggers: ['new to gym', 'beginner workout', 'starting exercise', 'নতুন জিম', 'প্রথম ব্যায়াম'],
    intent: 'workout',
    responseTemplates: {
      en: 'Start with 3 days per week of full-body workouts. Focus on form over weight. Rest days are when muscles recover and grow. Progress gradually.',
      bn: 'সপ্তাহে ৩ দিন ফুল-বডি ওয়ার্কআউট দিয়ে শুরু করুন। ওজনের চেয়ে ফর্মে মনোযোগ দিন। বিশ্রামের দিনে পেশি পুনরুদ্ধার ও বৃদ্ধি পায়।',
      bnEn: 'Soptaje 3 din full-body workout diye shuru korun. Ojoner cheye forme monojog din. Bishramer dine peshi punoruddho o briddhi pay.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'ACSM Beginner Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'workout_recovery', triggers: ['recovery', 'rest day', 'sore', 'DOMS', 'পুনরুদ্ধার', 'বিশ্রাম'],
    intent: 'workout',
    responseTemplates: {
      en: 'Muscles grow during rest, not during exercise. Allow 48 hours between training the same muscle group. Sleep 7-9 hours and eat enough protein for recovery.',
      bn: 'পেশি বিশ্রামের সময় বাড়ে, ব্যায়ামের সময় নয়। একই পেশি গোষ্ঠীর মধ্যে ৪৮ ঘন্টা সময় দিন। ৭-৯ ঘন্টা ঘুমান এবং পর্যাপ্ত প্রোটিন খান।',
      bnEn: 'Peshi bishramer somoy bare, byayamer somoy noy. Eki peshi goshthir moddhe 48 ghonta somoy din. 7-9 ghonta ghuman ebong porjapto protein khan.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'ACSM Recovery Guidelines', lastUpdated: '2024-01',
  },
  {
    id: 'study_active_recall', triggers: ['active recall', 'retrieval practice', 'অ্যাক্টিভ রিকল', 'how to remember'],
    intent: 'study',
    responseTemplates: {
      en: 'Active recall (testing yourself instead of re-reading) is one of the most effective study techniques. Research shows it improves long-term retention significantly more than passive review.',
      bn: 'অ্যাক্টিভ রিকল (পুনরায় পড়ার পরিবর্তে নিজেকে পরীক্ষা করা) সবচেয়ে কার্যকর পড়াশোনার কৌশলগুলির একটি। এটি দীর্ঘমেয়াদী স্মৃতি উল্লেখযোগ্যভাবে উন্নত করে।',
      bnEn: 'Active recall (punoraye porar poriborte nijekye porikkha kora) sobcheye kargikoro porashonar koushologuli ekoti. Eti dirghomeyadi smriti ullekhjogbhabe unnoto kore.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'Roediger & Karpicke (2006)', lastUpdated: '2024-01',
  },
  {
    id: 'study_spaced_rep', triggers: ['spaced repetition', 'space out study', 'ব্যবধান পুনরাবৃত্তি', 'when to review'],
    intent: 'study',
    responseTemplates: {
      en: 'Spaced repetition means reviewing material at increasing intervals (1 day, 3 days, 7 days) instead of cramming. This strengthens memory traces and is far more efficient.',
      bn: 'ব্যবধান পুনরাবৃত্তি মানে ক্রমবর্ধমান ব্যবধানে উপাদান পর্যালোচনা করা। এটি স্মৃতি শক্তিশালী করে এবং অনেক বেশি কার্যকর।',
      bnEn: 'Byabodhan punorabritti mane kromobordhoman byabodhane upadan porjalochona kora. Eti smriti shoktishali kore ebong onek beshi kargikoro.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'Ebbinghaus / Cepeda et al. (2006)', lastUpdated: '2024-01',
  },
  {
    id: 'study_sleep', triggers: ['sleep and study', 'sleep before exam', 'ঘুম এবং পড়াশোনা', 'all nighter'],
    intent: 'study',
    responseTemplates: {
      en: 'Sleep plays a critical role in long-term memory formation. An all-nighter hurts recall. Aim for 7-9 hours, especially before an exam — your brain consolidates what you learned during sleep.',
      bn: 'ঘুম দীর্ঘমেয়াদী স্মৃতি গঠনে গুরুত্বপূর্ণ ভূমিকা রাখে। সারারাত জাগা স্মৃতি কমায়। পরীক্ষার আগে ৭-৯ ঘন্টা ঘুমানোর লক্ষ্য রাখুন।',
      bnEn: 'Ghum dirghomeyadi smriti gothone guruttoborno bhromika rakhhe. Sararat jaga smriti komay. Porikhar age 7-9 ghonta ghumanor lokkho rakun.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'Walker (2017), Sleep & Memory Research', lastUpdated: '2024-01',
  },
  {
    id: 'study_pomodoro', triggers: ['pomodoro', 'study blocks', 'focus timer', 'পড়ার সময়', 'concentration'],
    intent: 'study',
    responseTemplates: {
      en: 'Try focused study blocks of 25 minutes with 5-minute breaks (Pomodoro technique). After 4 blocks, take a 15-30 minute break. This manages cognitive load and maintains attention.',
      bn: '২৫ মিনিটের ফোকাসড পড়াশোনা ব্লক এবং ৫ মিনিট বিরতি (পমোডোরো কৌশল) চেষ্টা করুন। ৪ ব্লক পরে ১৫-৩০ মিনিট বড় বিরতি নিন।',
      bnEn: '25 miniter focused porashona block ebong 5 minut biroti (Pomodoro koushol) chesta korun. 4 block pore 15-30 minut boro biroti nin.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'Cognitive Load Theory / Pomodoro', lastUpdated: '2024-01',
  },
  {
    id: 'study_exam', triggers: ['exam', 'test preparation', 'পরীক্ষা', 'exam tips'],
    intent: 'study',
    responseTemplates: {
      en: "For exam prep: 1) Use active recall — test yourself. 2) Use spaced repetition — review at increasing intervals. 3) Sleep well — memory consolidates during sleep. 4) Start early, avoid cramming.",
      bn: 'পরীক্ষার প্রস্তুতির জন্য: ১) অ্যাক্টিভ রিকল ব্যবহার করুন। ২) ব্যবধান পুনরাবৃত্তি ব্যবহার করুন। ৩) ভালো ঘুমান। ৪) আগে শুরু করুন, শেষ মুহূর্তে ভর করবেন না।',
      bnEn: 'Porikhar prostutir jonno: 1) Active recall byabohar korun. 2) Byabodhan punorabritti byabohar korun. 3) Valo ghuman. 4) Agey shuru korun, shesh muhurte bhor korben na.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'Multiple: Roediger, Dunlosky, Rawson', lastUpdated: '2024-01',
  },
  {
    id: 'study_procrastination', triggers: ['procrastination', 'procrastinate', "can't start", 'ঝুকি', 'টাল', 'শুরু করতে পারছি না'],
    intent: 'study',
    responseTemplates: {
      en: "Break the task into a tiny 2-minute first step. Starting is the hardest part — once you begin, momentum builds. Use the 5-minute rule: commit to just 5 minutes, then decide whether to continue.",
      bn: 'কাজটিকে একটি ছোট ২-মিনিটের প্রথম ধাপে ভাগ করুন। শুরু করাই সবচেয়ে কঠিন। ৫-মিনিট নিয়ম ব্যবহার করুন: মাত্র ৫ মিনিট প্রতিশ্রুতি দিন।',
      bnEn: 'Kajtike ekoti choto 2-miniter prothom dhape bhag korun. Shuru korai sobcheye kothin. 5-minit niyom byabohar korun: matra 5 minut protishruti din.',
    },
    safetyLevel: 'safe', confidence: 'medium', source: 'Behavioral Psychology / Implementation Intentions', lastUpdated: '2024-01',
  },
  {
    id: 'habit_building', triggers: ['build habit', 'new habit', 'অভ্যাস গঠন', 'habit loop', 'daily routine'],
    intent: 'habits',
    responseTemplates: {
      en: "To build a habit: 1) Start tiny — make it so small you can't say no. 2) Attach it to an existing routine (habit stacking). 3) Track it daily. Consistency matters more than intensity.",
      bn: 'অভ্যাস গঠনের জন্য: ১) ছোট শুরু করুন। ২) বিদ্যমান রুটিনের সাথে যুক্ত করুন। ৩) প্রতিদিন ট্র্যাক করুন। ধারাবাহিকতা তীব্রতার চেয়ে বেশি গুরুত্বপূর্ণ।',
      bnEn: 'Abhyas gothoner jonno: 1) Choto shuru korun. 2) Biddoman routiner sathe jukto korun. 3) Protidin track korun. Dharabahikota tibrotar cheye beshi guruttoborno.',
    },
    safetyLevel: 'safe', confidence: 'high', source: 'James Clear, Atomic Habits', lastUpdated: '2024-01',
  },
  {
    id: 'habit_consistency', triggers: ['consistency', 'stick to', 'নিয়মিত', 'keep going', 'motivation'],
    intent: 'habits',
    responseTemplates: {
      en: "Missing one day doesn't break a habit — but missing two days starts a new pattern. The \"never miss twice\" rule helps maintain consistency without being rigid.",
      bn: 'একদিন মিস করা অভ্যাস ভাঙে না — কিন্তু দুইদিন মিস করলে নতুন প্যাটার্ন শুরু হয়। "দুইবার মিস করবেন না" নিয়মটি ধারাবাহিকতা বজায় রাখতে সাহায্য করে।',
      bnEn: 'Ekdin mis kora abhyas bhange na — kintu duidin mis korle notun pattern shuru hoy. "Duibar mis korben na" niyomti dharabahikota bojaye rakhte sahajjo kore.',
    },
    safetyLevel: 'safe', confidence: 'medium', source: 'Lally et al. (2010)', lastUpdated: '2024-01',
  },
  {
    id: 'productivity_morning', triggers: ['morning routine', 'start day', 'সকালের রুটিন', 'morning plan'],
    intent: 'productivity',
    responseTemplates: {
      en: 'A strong morning routine sets the tone. Try: 1) Wake at a consistent time. 2) Hydrate first. 3) Do your hardest task within the first 2 hours (eat the frog). 4) Review your daily plan.',
      bn: 'একটি শক্তিশালী সকালের রুটিন দিনের স্বর নির্ধারণ করে। চেষ্টা করুন: ১) নির্দিষ্ট সময়ে উঠুন। ২) প্রথমে পানি পান করুন। ৩) প্রথম ২ ঘন্টায় সবচেয়ে কঠিন কাজটি করুন।',
      bnEn: 'Ekoti shoktishali sokaler routine diner swor nirdhoron kore. Chesta korun: 1) Nirdhisto somoye uthun. 2) Prothome pani pan korun. 3) Prothom 2 ghontay sobcheye kothin kajti korun.',
    },
    safetyLevel: 'safe', confidence: 'medium', source: 'Productivity Research / Eat the Frog', lastUpdated: '2024-01',
  },
  {
    id: 'general_greeting', triggers: ['hello', 'hi', 'hey', 'হ্যালো', 'কেমন আছো'],
    intent: 'greeting',
    responseTemplates: {
      en: "Hello! I'm your growth assistant. I can help with diet, workouts, study techniques, habits, and productivity. What would you like to work on today?",
      bn: 'হ্যালো! আমি আপনার গ্রোথ অ্যাসিস্ট্যান্ট। ডায়েট, ওয়ার্কআউট, পড়াশোনা, অভ্যাস এবং উৎপাদনশীলতায় সাহায্য করতে পারি। আজ কী নিয়ে কাজ করতে চান?',
      bnEn: "Hello! Ami apnar growth assistant. Diet, workout, porashona, abhyas ebong utpadonshilitay sahajjo korte pari. Aj ki niye kaj korte chan?",
    },
    safetyLevel: 'safe', confidence: 'high', source: '', lastUpdated: '2024-01',
  },
  {
    id: 'general_help', triggers: ['what can you', 'help me', 'সাহায্য', 'what do you do'],
    intent: 'general_help',
    responseTemplates: {
      en: "I can help you with:\n- Diet & nutrition tips\n- Workout & exercise guidance\n- Study techniques & exam prep\n- Building habits & routines\n- Productivity advice\n\nI use your app data to give personalized suggestions!",
      bn: 'আমি সাহায্য করতে পারি:\n- ডায়েট ও পুষ্টি টিপস\n- ওয়ার্কআউট নির্দেশনা\n- পড়াশোনার কৌশল ও পরীক্ষার প্রস্তুতি\n- অভ্যাস ও রুটিন গঠন\n- উৎপাদনশীলতা পরামর্শ',
      bnEn: 'Ami sahajjo korte pari:\n- Diet o pushti tips\n- Workout nirdeshona\n- Porashonar koushol o porikhar prostuti\n- Abhyas o routine gothon\n- Utpadonshilita paramarsha',
    },
    safetyLevel: 'safe', confidence: 'high', source: '', lastUpdated: '2024-01',
  },
];
