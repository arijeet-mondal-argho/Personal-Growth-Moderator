const ESCALATION_KEYWORDS = [
  'chest pain', 'suicide', 'kill myself', 'self harm', 'self-harm', 'dying', 'overdose',
  'emergency', 'heart attack', 'seizure', 'unconscious', 'cant breathe', "can't breathe",
  'severe pain', 'প্রাণঘাত', 'আত্মহত্যা', 'মৃত্যু', 'জরুরি', 'বুকে ব্যথা', 'শ্বাস', 'অজ্ঞান',
];

export function isUnsafeQuery(text: string): boolean {
  const lower = text.toLowerCase();
  return ESCALATION_KEYWORDS.some((kw) => lower.includes(kw));
}

export function getEscalationResponse(lang: 'en' | 'bn' | 'bnEn'): string {
  const responses = {
    en: "I'm not able to help with this. If you're in danger or experiencing a medical emergency, please contact a healthcare professional or emergency services immediately.\n\nEmergency contacts:\n- Bangladesh: 999\n- International: Contact your local emergency number",
    bn: "আমি এই বিষয়ে সাহায্য করতে পারছি না। আপনি যদি বিপদে থাকেন বা চিকিৎসা জরুরি প্রয়োজন হয়, দয়া করে একজন চিকিৎসক বা জরুরি সেবায় যোগাযোগ করুন।\n\nজরুরি নম্বর: বাংলাদেশ: ৯৯৯",
    bnEn: "Ami ei bishe help korte parchi na. Apni jodi bipode thaken ba chikitsha juri proyojon hoy, daya kore ekjon chikitshok ba jururi sebay jogajog korun.\n\nJururi number: Bangladesh - 999",
  };
  return responses[lang];
}

export const DISCLAIMER = {
  en: "This is general guidance, not medical advice. Always consult a professional for personal health decisions.",
  bn: "এটি সাধারণ পরামর্শ, চিকিৎসা পরামর্শ নয়। ব্যক্তিগত স্বাস্থ্য সিদ্ধান্তের জন্য সবসময় একজন বিশেষজ্ঞের পরামর্শ নিন।",
  bnEn: "Eti sadharan paramarsha, chikitsha paramarsha noy. Byaktigon swastho sidhdhantor jonno sob somoy ekjon bisheshoger paramarsha nin.",
};
