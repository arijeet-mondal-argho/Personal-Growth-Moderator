import type { ChatIntent } from '../lib/types';
import { getTextForAnalysis } from './language';

const INTENT_KEYWORDS: Record<ChatIntent, string[]> = {
  diet: ['diet', 'food', 'eat', 'meal', 'protein', 'carbs', 'fat', 'calorie', 'kcal', 'nutrition', 'macro', 'খাবার', 'খাদ্য', 'প্রোটিন', 'ডায়েট', 'পুষ্টি', 'ক্যালোরি', 'ভাত', 'মাছ', 'মাংস', 'ডিম', 'দুধ'],
  workout: ['workout', 'exercise', 'gym', 'lift', 'run', 'cardio', 'strength', 'reps', 'sets', 'ব্যায়াম', 'জিম', 'দৌড়', 'শক্তি'],
  study: ['study', 'learn', 'exam', 'read', 'focus', 'memory', 'recall', 'repetition', 'পড়া', 'পড়াশোনা', 'পরীক্ষা', 'মেমোরি', 'ফোকাস', 'শিখ', 'শিক্ষা'],
  productivity: ['productivity', 'task', 'todo', 'routine', 'schedule', 'time', 'manage', 'plan', 'কাজ', 'রুটিন', 'সূচি', 'সময়', 'পরিকল্পনা'],
  habits: ['habit', 'discipline', 'consistency', 'streak', 'daily', 'morning', 'অভ্যাস', 'নিয়ম', 'নিয়মিত', 'সকাল'],
  routine: ['routine', 'morning', 'evening', 'schedule', 'daily', 'plan', 'রুটিন', 'সকাল', 'সন্ধ্যা', 'দৈনন্দিন'],
  reminders: ['remind', 'remember', 'forget', 'alarm', 'টিকা', 'মনে', 'ভুলে'],
  safety_escalation: ['chest pain', 'suicide', 'kill', 'self harm', 'self-harm', 'dying', 'overdose', 'emergency', 'heart attack', 'seizure', 'unconscious', 'প্রাণঘাত', 'আত্মহত্যা', 'মৃত্যু', 'জরুরি', 'বুকে ব্যথা', 'হার্ট'],
  general_help: ['help', 'what can you', 'সাহায্য', 'কি করতে পারো'],
  greeting: ['hi', 'hello', 'hey', 'good morning', 'good evening', 'how are you', 'হ্যালো', 'সুপ্রভাত', 'কেমন আছো', 'কেমন আছেন'],
};

export function detectIntent(text: string): ChatIntent {
  const analyzed = getTextForAnalysis(text).toLowerCase();
  const safetyKeywords = INTENT_KEYWORDS.safety_escalation;
  if (safetyKeywords.some((kw) => analyzed.includes(kw.toLowerCase()))) return 'safety_escalation';

  let bestIntent: ChatIntent = 'general_help';
  let bestScore = 0;
  for (const [intent, keywords] of Object.entries(INTENT_KEYWORDS)) {
    if (intent === 'safety_escalation') continue;
    const score = keywords.filter((kw) => analyzed.includes(kw.toLowerCase())).length;
    if (score > bestScore) { bestScore = score; bestIntent = intent as ChatIntent; }
  }
  return bestScore > 0 ? bestIntent : 'general_help';
}
