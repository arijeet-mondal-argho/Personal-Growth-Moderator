import type { ChatIntent, ConfidenceLevel, Language } from '../lib/types';
import { detectLanguage, getTextForAnalysis } from './language';
import { detectIntent } from './intent';
import { isUnsafeQuery, getEscalationResponse } from './safety';
import { KNOWLEDGE_BASE } from './knowledge';
import { getAppData, getContextualAddendum } from './dataProvider';
import { formatResponse } from './response';
import { useChatStore } from '../store/useChatStore';

export function processMessage(userText: string): void {
  const chatStore = useChatStore.getState();

  chatStore.addMessage({ role: 'user', content: userText });

  const lang = detectLanguage(userText);
  const analyzedText = getTextForAnalysis(userText);

  if (isUnsafeQuery(analyzedText)) {
    chatStore.addMessage({
      role: 'assistant', content: getEscalationResponse(lang),
      confidence: 'unsafe', source: 'Safety Protocol', intent: 'safety_escalation', suggestions: [],
    });
    return;
  }

  const intent = detectIntent(userText);
  const matchedRules = KNOWLEDGE_BASE.filter((rule) =>
    rule.intent === intent && rule.triggers.some((trigger) => analyzedText.toLowerCase().includes(trigger.toLowerCase()))
  );

  const appData = getAppData();

  if (matchedRules.length > 0) {
    const rule = matchedRules[0];
    const addendum = getContextualAddendum(intent, appData, lang);
    const template = rule.responseTemplates[lang] || rule.responseTemplates.en;
    const formatted = formatResponse(template, lang, intent, rule.confidence, rule.source, addendum);
    chatStore.addMessage({
      role: 'assistant', content: formatted.content, confidence: formatted.confidence,
      source: formatted.source, intent: formatted.intent, suggestions: formatted.suggestions,
    });
  } else {
    const fallback = getFallbackResponse(intent, lang, appData);
    chatStore.addMessage({
      role: 'assistant', content: fallback.content, confidence: fallback.confidence,
      source: '', intent, suggestions: fallback.suggestions,
    });
  }
}

function getFallbackResponse(intent: ChatIntent, lang: Language, appData: ReturnType<typeof getAppData>) {
  const addendum = getContextualAddendum(intent, appData, lang);

  const fallbacks: Record<ChatIntent, { en: string; bn: string; bnEn: string }> = {
    diet: { en: "I'd like to help with diet. Could you be more specific? Ask about protein needs, calorie goals, or meal timing.", bn: 'আরো নির্দিষ্ট হলে ভালো পরামর্শ দিতে পারি। প্রোটিন, ক্যালোরি, বা খাবারের সময় সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Aro nirdishto hole valo paramarsha dite pari. Protein, calorie, ba khabarer somoy somporke jiggesha korun.' },
    workout: { en: 'I can help with workouts. Try asking about beginner plans, weekly goals, or recovery tips.', bn: 'ওয়ার্কআউটে সাহায্য করতে পারি। নতুনদের পরিকল্পনা, সাপ্তাহিক লক্ষ্য, বা পুনরুদ্ধার সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Workoute sahajjo korte pari. Notuder porikolpana, saptahik lokkho, ba punoruddhar somporke jiggesha korun.' },
    study: { en: 'I can help with study techniques. Ask about active recall, spaced repetition, or exam prep.', bn: 'পড়াশোনার কৌশলে সাহায্য করতে পারি। অ্যাক্টিভ রিকল, ব্যবধান পুনরাবৃত্তি, বা পরীক্ষার প্রস্তুতি সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Porashonar koushole sahajjo korte pari. Active recall, byabodhan punorabritti, ba porikhar prostuti somporke jiggesha korun.' },
    productivity: { en: 'I can help with productivity. Ask about morning routines, time management, or habit building.', bn: 'উৎপাদনশীলতায় সাহায্য করতে পারি। সকালের রুটিন, সময় ব্যবস্থাপনা সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Utpadonshilitay sahajjo korte pari. Sokaler routine, somoy byabosthapon somporke jiggesha korun.' },
    habits: { en: 'I can help with habit building. Ask about starting small or staying consistent.', bn: 'অভ্যাস গঠনে সাহায্য করতে পারি। ছোট শুরু বা নিয়মিত থাকা সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Abhyas gothone sahajjo korte pari. Choto shuru ba niyomit thaka somporke jiggesha korun.' },
    routine: { en: 'I can help with routines. Ask about morning or evening routines, or daily scheduling.', bn: 'রুটিনে সাহায্য করতে পারি। সকাল বা সন্ধ্যার রুটিন সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Routiney sahajjo korte pari. Sokal ba sandhyar routine somporke jiggesha korun.' },
    reminders: { en: 'I can help with task management. Ask about your tasks for today.', bn: 'টাস্ক ম্যানেজমেন্টে সাহায্য করতে পারি। আজকের টাস্ক সম্পর্কে জিজ্ঞাসা করুন।', bnEn: 'Task managemente sahajjo korte pari. Ajker task somporke jiggesha korun.' },
    safety_escalation: { en: '', bn: '', bnEn: '' },
    general_help: { en: "I'm your growth assistant. I can help with diet, workouts, study, habits, and productivity. What area interests you?", bn: 'আমি আপনার গ্রোথ অ্যাসিস্ট্যান্ট। ডায়েট, ওয়ার্কআউট, পড়াশোনা, অভ্যাস এবং উৎপাদনশীলতায় সাহায্য করতে পারি। কোন ক্ষেত্রে আগ্রহী?', bnEn: 'Ami apnar growth assistant. Diet, workout, porashona, abhyas ebong utpadonshilitay sahajjo korte pari. Kon khetre agrahi?' },
    greeting: { en: 'Hey there! How can I help you grow today?', bn: 'হ্যালো! আজ কীভাবে সাহায্য করতে পারি?', bnEn: 'Hello! Aj kibhabe sahajjo korte pari?' },
  };

  let content = fallbacks[intent]?.[lang] || fallbacks.general_help[lang];
  if (addendum) content = `${content}\n\n${addendum}`;

  const suggestionMap: Record<ChatIntent, string[]> = {
    diet: ['How much protein do I need?', 'Healthy meal tips', 'Hydration advice'],
    workout: ['Beginner workout plan', 'Weekly exercise goals', 'Recovery tips'],
    study: ['What is active recall?', 'Spaced repetition guide', 'Exam tips'],
    productivity: ['Morning routine plan', 'Time management tips', 'Focus techniques'],
    habits: ['How to build a habit', 'Consistency tips', 'Habit tracking'],
    routine: ['Morning routine ideas', 'Daily schedule tips', 'Evening wind-down'],
    reminders: ['My tasks for today', 'Set a recurring task'],
    safety_escalation: [],
    general_help: ['Diet tips', 'Study hacks', 'Workout advice'],
    greeting: ['Diet tips', 'Study hacks', 'Workout advice'],
  };

  return { content, confidence: 'low' as ConfidenceLevel, suggestions: suggestionMap[intent] || [] };
}
