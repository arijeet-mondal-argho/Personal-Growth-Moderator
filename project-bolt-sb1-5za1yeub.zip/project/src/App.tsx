import { useState, useEffect } from 'react';
import type { NavTab } from './lib/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from './lib/storage';
import BottomNav from './components/layout/BottomNav';
import DashboardPage from './modules/dashboard/DashboardPage';
import TaskPage from './modules/tasks/TaskPage';
import DietPage from './modules/diet/DietPage';
import WorkoutPage from './modules/workout/WorkoutPage';
import StudyPage from './modules/study/StudyPage';
import ChatPage from './modules/chatbot/ChatPage';

const PAGES: Record<NavTab, () => JSX.Element> = {
  dashboard: DashboardPage,
  tasks: TaskPage,
  diet: DietPage,
  workout: WorkoutPage,
  study: StudyPage,
  chat: ChatPage,
};

function App() {
  const [activeTab, setActiveTab] = useState<NavTab>(
    loadFromStorage<NavTab>(STORAGE_KEYS.activeTab, 'dashboard')
  );

  useEffect(() => { saveToStorage(STORAGE_KEYS.activeTab, activeTab); }, [activeTab]);

  const Page = PAGES[activeTab];

  return (
    <div className="h-screen flex flex-col max-w-lg mx-auto bg-slate-950">
      <div className="flex-1 overflow-hidden">
        <Page />
      </div>
      <BottomNav active={activeTab} onChange={setActiveTab} />
    </div>
  );
}

export default App;
